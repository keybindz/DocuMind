"""Pydantic schemas for request/response validation and serialization."""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from app.models import DocumentStatus, UserRole


# --- Auth ---

class SignupRequest(BaseModel):
    tenant_name: str = Field(min_length=1, max_length=255)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    tenant_id: uuid.UUID
    email: EmailStr
    role: UserRole
    created_at: datetime


class SignupResponse(BaseModel):
    user: UserOut
    token: Token


# --- Documents ---

class DocumentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    filename: str
    mime_type: str
    size_bytes: int
    status: DocumentStatus
    error_message: str | None = None
    char_count: int | None = None
    created_at: datetime
    processed_at: datetime | None = None


class DocumentContentOut(BaseModel):
    id: uuid.UUID
    filename: str
    extracted_text: str | None = None


class DocumentListOut(BaseModel):
    items: list[DocumentOut]
    total: int
    limit: int
    offset: int


class ErrorResponse(BaseModel):
    detail: str
