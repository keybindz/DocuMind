import hashlib
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, status
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import get_db
from app.dependencies import get_current_user
from app.models import Document, DocumentStatus, User
from app.schemas import DocumentContentOut, DocumentListOut, DocumentOut
from app.services.extraction import ExtractionError, extract_text
from app.services.storage import StorageBackend, get_storage_backend

router = APIRouter(prefix="/v1/documents", tags=["documents"])
settings = get_settings()


def _get_owned_document(db: Session, document_id: uuid.UUID, tenant_id: uuid.UUID) -> Document:
    """
    Fetches a document scoped to the caller's tenant. Filtering by tenant_id
    in the WHERE clause (rather than fetching by id then checking) means a
    request for another tenant's document ID returns an indistinguishable
    404 — not a 403 that would confirm the ID exists.
    """
    document = (
        db.query(Document)
        .filter(Document.id == document_id, Document.tenant_id == tenant_id)
        .first()
    )
    if document is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    return document


@router.post("", response_model=DocumentOut, status_code=status.HTTP_201_CREATED)
async def upload_document(
    file: UploadFile,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    storage: StorageBackend = Depends(get_storage_backend),
):
    """
    Uploads a document and extracts its text synchronously.

    Synchronous extraction is a deliberate Phase 1 simplification for small
    files/fast feedback in a demo. Phase 4 moves this to `pending` + a queued
    background job so upload latency doesn't scale with file size.
    """
    if file.content_type not in settings.ALLOWED_MIME_TYPES:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=f"Unsupported file type: {file.content_type}",
        )

    content = await file.read()
    if len(content) > settings.MAX_UPLOAD_SIZE_BYTES:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File exceeds max size of {settings.MAX_UPLOAD_SIZE_BYTES} bytes",
        )
    if not content:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Uploaded file is empty")

    file_hash = hashlib.sha256(content).hexdigest()

    # Dedupe: if this tenant already uploaded this exact file, return it as-is
    # rather than reprocessing and storing a duplicate copy.
    existing = (
        db.query(Document)
        .filter(Document.tenant_id == current_user.tenant_id, Document.file_hash == file_hash)
        .first()
    )
    if existing:
        return existing

    document = Document(
        tenant_id=current_user.tenant_id,
        uploaded_by=current_user.id,
        filename=file.filename or "untitled",
        storage_path="",  # set below once we know the document id
        mime_type=file.content_type,
        file_hash=file_hash,
        size_bytes=len(content),
        status=DocumentStatus.pending,
    )
    db.add(document)
    db.flush()  # populate document.id

    storage_path = storage.save(
        tenant_id=current_user.tenant_id,
        document_id=document.id,
        filename=document.filename,
        content=content,
    )
    document.storage_path = storage_path
    document.status = DocumentStatus.extracting

    try:
        text = extract_text(content, file.content_type)
        document.extracted_text = text
        document.char_count = len(text)
        document.status = DocumentStatus.ready
        document.processed_at = datetime.now(timezone.utc)
    except ExtractionError as exc:
        document.status = DocumentStatus.failed
        document.error_message = str(exc)

    db.commit()
    db.refresh(document)
    return document


@router.get("", response_model=DocumentListOut)
def list_documents(
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    base_query = db.query(Document).filter(Document.tenant_id == current_user.tenant_id)
    total = base_query.count()
    items = (
        base_query.order_by(Document.created_at.desc()).offset(offset).limit(limit).all()
    )
    return DocumentListOut(items=items, total=total, limit=limit, offset=offset)


@router.get("/{document_id}", response_model=DocumentOut)
def get_document(
    document_id: uuid.UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _get_owned_document(db, document_id, current_user.tenant_id)


@router.get("/{document_id}/content", response_model=DocumentContentOut)
def get_document_content(
    document_id: uuid.UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    document = _get_owned_document(db, document_id, current_user.tenant_id)
    if document.status != DocumentStatus.ready:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Document is not ready (status={document.status.value})",
        )
    return DocumentContentOut(id=document.id, filename=document.filename, extracted_text=document.extracted_text)


@router.delete("/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_document(
    document_id: uuid.UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    storage: StorageBackend = Depends(get_storage_backend),
):
    document = _get_owned_document(db, document_id, current_user.tenant_id)
    storage.delete(document.storage_path)
    db.delete(document)
    db.commit()
    return None
