"""
Centralized application settings.

All configuration is read from environment variables (or a .env file in
local dev). Nothing here should be hardcoded per-environment — the same
image is deployed to dev/staging/prod with different env vars.
"""
from functools import lru_cache

import email_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Email format is still validated (RFC syntax, domain shape) — only the
# live DNS/MX "does this domain accept mail" check is disabled. Deliverability
# checking makes signup depend on network/DNS at request time, which is
# fragile in CI, in offline dev, and behind restrictive egress rules, and it
# isn't actually necessary: an undeliverable address just bounces later.
email_validator.CHECK_DELIVERABILITY = False


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- App ---
    APP_NAME: str = "DocuMind"
    ENV: str = "development"
    DEBUG: bool = True

    # --- Database ---
    # Example (docker-compose): postgresql+psycopg2://documind:documind@postgres:5432/documind
    DATABASE_URL: str = "sqlite:///./documind_dev.db"
    # Dev convenience only. In staging/prod, schema changes go through Alembic
    # migrations (`alembic upgrade head`), never through metadata.create_all().
    AUTO_CREATE_TABLES: bool = True

    # --- Auth ---
    SECRET_KEY: str = "change-me-in-production"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24h — fine for a demo/portfolio project

    # --- Storage ---
    # Local filesystem for Phase 1. Swapped for an S3/MinIO-backed
    # implementation behind the same StorageBackend interface in a later phase.
    STORAGE_DIR: str = "./storage_data"

    # --- Uploads ---
    MAX_UPLOAD_SIZE_BYTES: int = 20 * 1024 * 1024  # 20 MB
    ALLOWED_MIME_TYPES: tuple[str, ...] = (
        "application/pdf",
        "text/plain",
        "text/markdown",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",  # .docx
    )


@lru_cache
def get_settings() -> Settings:
    return Settings()
