# DocuMind — Phase 1

Multi-tenant document intelligence platform. **Phase 1 scope:** tenant/user
auth (JWT), document upload, and synchronous text extraction (PDF, DOCX,
TXT, MD). No embeddings, vector search, or background workers yet — those
land in Phases 2–4.

## Stack

- **FastAPI** — API layer
- **PostgreSQL** (via SQLAlchemy 2.0) — relational data: tenants, users, documents
- **Alembic** — schema migrations
- **JWT** (python-jose) + **bcrypt** (passlib) — auth
- **pypdf / python-docx** — text extraction
- **Docker Compose** — local dev environment
- **pytest** — test suite (runs against in-memory SQLite, no Docker required)

## Architecture notes worth knowing before you read the code

- **Multi-tenancy is in the schema from day one.** Every tenant-owned table
  (`users`, `documents`) has a `tenant_id`, and every query is filtered by
  the caller's tenant. Row-Level Security as a second enforcement layer,
  plus explicit cross-tenant-leak tests, are added in Phase 3 — the schema
  won't need to change then.
- **Cross-dialect UUID type** (`app/database.py::GUID`): native `UUID` on
  Postgres, `CHAR(36)` on SQLite. This is what lets the test suite run fast
  against in-memory SQLite while production runs Postgres, from the exact
  same models.
- **Storage is behind an interface** (`app/services/storage.py`). Phase 1
  uses local disk; a later phase swaps in an S3/MinIO-backed implementation
  without touching the API or the schema — `storage_path` is already shaped
  like an S3 key (`{tenant_id}/{document_id}_{filename}`).
- **Extraction is synchronous for now** (`app/services/extraction.py`).
  Phase 4 moves this behind a message queue + worker; the extraction
  function itself won't change, only who calls it and when.
- **404, not 403, for cross-tenant access.** Looking up another tenant's
  document by ID returns 404 rather than 403 — it doesn't confirm the ID
  exists. See `test_tenant_isolation_cannot_see_other_tenants_documents`.

## Quickstart (Docker — recommended)

```bash
docker compose up --build
```

This starts Postgres and the API with hot-reload. The API is at
`http://localhost:8000`, interactive docs at `http://localhost:8000/docs`.

Tables are auto-created on startup for this phase (`AUTO_CREATE_TABLES=true`
in `docker-compose.yml`). From Phase 5 onward, CI/CD runs
`alembic upgrade head` as an explicit deploy step instead — the Alembic
setup is already here and working (see "Migrations" below) if you want to
use it now.

## Quickstart (without Docker)

Requires Python 3.12+ and a running Postgres instance (or just use the
SQLite default for a quick look).

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env      # edit DATABASE_URL if not using the SQLite default
uvicorn app.main:app --reload
```

## Demo script (run against either setup)

```bash
BASE=http://localhost:8000

# 1. Sign up — creates a tenant + owner user, returns a JWT
curl -s -X POST $BASE/v1/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"tenant_name":"Acme Corp","email":"demo@acme.io","password":"supersecret123"}' | tee /tmp/signup.json
TOKEN=$(python -c "import json;print(json.load(open('/tmp/signup.json'))['token']['access_token'])")

# 2. Log in (alternative to using the signup token directly)
curl -s -X POST $BASE/v1/auth/login \
  -d "username=demo@acme.io&password=supersecret123"

# 3. Upload a document
echo "Vector databases enable semantic search over unstructured text." > sample.txt
curl -s -X POST $BASE/v1/documents \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@sample.txt;type=text/plain" | tee /tmp/upload.json
DOC_ID=$(python -c "import json;print(json.load(open('/tmp/upload.json'))['id'])")

# 4. List documents
curl -s $BASE/v1/documents -H "Authorization: Bearer $TOKEN"

# 5. Get extracted content
curl -s $BASE/v1/documents/$DOC_ID/content -H "Authorization: Bearer $TOKEN"

# 6. Confirm auth is enforced
curl -s -o /dev/null -w "%{http_code}\n" $BASE/v1/documents   # -> 401

# 7. Delete it
curl -s -o /dev/null -w "%{http_code}\n" -X DELETE $BASE/v1/documents/$DOC_ID \
  -H "Authorization: Bearer $TOKEN"   # -> 204
```

Or skip curl entirely and use the Swagger UI at `/docs` — click "Authorize",
paste `Bearer <token>` from the signup response, and try every endpoint
interactively.

## Running the tests

```bash
pytest -v
```

19 tests, no Docker/Postgres required — they run against an isolated
in-memory SQLite database per test via fixtures in `tests/conftest.py`.
Covers: signup/login validation, JWT auth enforcement, upload + extraction
for txt/docx, graceful handling of corrupt/unsupported files, dedup by
content hash, pagination, deletion, and — importantly — that Tenant B can
neither fetch nor list Tenant A's documents.

## Migrations

An initial migration already exists (`alembic/versions/`). To use Alembic
instead of `AUTO_CREATE_TABLES`:

```bash
export AUTO_CREATE_TABLES=false
alembic upgrade head        # apply
alembic downgrade base      # roll back (tested — both directions work)
alembic revision --autogenerate -m "description"   # after changing models.py
```

## API surface (Phase 1)

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/v1/auth/signup` | — | Create tenant + owner user, returns JWT |
| POST | `/v1/auth/login` | — | Exchange email/password for JWT |
| POST | `/v1/documents` | JWT | Upload + synchronously extract a document |
| GET | `/v1/documents` | JWT | List tenant's documents (paginated) |
| GET | `/v1/documents/{id}` | JWT | Get one document's metadata |
| GET | `/v1/documents/{id}/content` | JWT | Get extracted text (409 if not ready) |
| DELETE | `/v1/documents/{id}` | JWT | Delete document + underlying file |
| GET | `/health` | — | Liveness check |

## What's deliberately *not* here yet

- Vector DB / embeddings / semantic search → **Phase 2**
- Row-Level Security + explicit isolation hardening → **Phase 3**
- Async ingestion via message queue + worker, webhooks → **Phase 4**
- Observability (metrics/tracing/logging), CI/CD, Kubernetes → **Phase 5**
- Hybrid search, re-ranking, usage-based billing → **Phase 6**
