"""
Test fixtures.

Tests run against an in-memory SQLite database (via a StaticPool so the
same in-memory DB is shared across connections in a test) rather than
requiring Docker/Postgres to be running. This keeps `pytest` fast and
runnable in plain CI without spinning up containers, while the actual
Postgres-specific behavior (native UUID/JSONB types) is exercised by the
GUID type decorator itself, which is dialect-branching code you can unit
test directly if you want extra confidence.
"""
import shutil
import tempfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app
from app.services.embeddings import DeterministicFakeBackend, get_embedding_backend
from app.services.storage import LocalDiskStorage, get_storage_backend
from app.services.vector_store import InMemoryVectorStore, get_vector_store


@pytest.fixture()
def tmp_storage_dir():
    path = tempfile.mkdtemp(prefix="documind_test_storage_")
    yield path
    shutil.rmtree(path, ignore_errors=True)


@pytest.fixture()
def db_session(tmp_storage_dir):
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(bind=engine)
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture()
def client(db_session, tmp_storage_dir):
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    def override_get_storage_backend():
        return LocalDiskStorage(base_dir=tmp_storage_dir)

    # Fresh fake embedding backend + in-memory vector store per test, so
    # chunks/vectors from one test can never leak into another (mirrors the
    # per-test db_session). See services/embeddings.py and vector_store.py
    # for why these fakes exist: no network, no model download, no Qdrant.
    fake_embedding_backend = DeterministicFakeBackend()
    in_memory_vector_store = InMemoryVectorStore()

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_storage_backend] = override_get_storage_backend
    app.dependency_overrides[get_embedding_backend] = lambda: fake_embedding_backend
    app.dependency_overrides[get_vector_store] = lambda: in_memory_vector_store
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.fixture()
def auth_headers(client):
    """Signs up a fresh tenant/user and returns ready-to-use Authorization headers."""
    resp = client.post(
        "/v1/auth/signup",
        json={"tenant_name": "Acme Corp", "email": "owner@acme.io", "password": "supersecret123"},
    )
    assert resp.status_code == 201, resp.text
    token = resp.json()["token"]["access_token"]
    return {"Authorization": f"Bearer {token}"}
