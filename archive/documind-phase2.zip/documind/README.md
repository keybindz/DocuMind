# DocuMind — Phase 1 + 2

Multi-tenant document intelligence platform.

- **Phase 1:** tenant/user auth (JWT), document upload, synchronous text
  extraction (PDF, DOCX, TXT, MD).
- **Phase 2 (this update):** chunking, embeddings, a vector store, and a
  RAG query endpoint (`POST /v1/query`) with optional LLM answer synthesis.

Still no background workers / queue (Phase 4) or Row-Level Security
hardening (Phase 3) — see "What's deliberately not here yet" below.

## Stack

- **FastAPI** — API layer
- **PostgreSQL** (via SQLAlchemy 2.0) — relational data: tenants, users, documents, chunks
- **Qdrant** — vector store, for semantic search over chunk embeddings
- **sentence-transformers** (`all-MiniLM-L6-v2`) — local embedding model, no API key required
- **Anthropic API** (optional) — LLM answer synthesis over retrieved chunks
- **Alembic** — schema migrations
- **JWT** (python-jose) + **bcrypt** (passlib) — auth
- **pypdf / python-docx** — text extraction
- **Docker Compose** — local dev environment
- **pytest** — test suite (runs against in-memory SQLite + in-memory vector store, no Docker required)

## Architecture notes worth knowing before you read the code

- **Multi-tenancy is in the schema from day one.** Every tenant-owned table
  (`users`, `documents`) has a `tenant_id`, and every query is filtered by
  the caller's tenant. Row-Level Security as a second enforcement layer,
  plus explicit cross-tenant-leak tests, are added in Phase 3 — the schema
  won't need to change then.
- **Cross-dialect UUID type** (`app/database.py::GUID`): native `UUID` on
  Postgres, `CHAR(36)` on SQLite. This is what lets the test suite run fast
  against in-memory SQLite while production runs Postgres, from the exact
  same models.
- **Storage is behind an interface** (`app/services/storage.py`). Phase 1
  uses local disk; a later phase swaps in an S3/MinIO-backed implementation
  without touching the API or the schema — `storage_path` is already shaped
  like an S3 key (`{tenant_id}/{document_id}_{filename}`).
- **Extraction is synchronous for now** (`app/services/extraction.py`).
  Phase 4 moves this behind a message queue + worker; the extraction
  function itself won't change, only who calls it and when.
- **404, not 403, for cross-tenant access.** Looking up another tenant's
  document by ID returns 404 rather than 403 — it doesn't confirm the ID
  exists. See `test_tenant_isolation_cannot_see_other_tenants_documents`.
- **Embeddings and the vector store are behind swappable interfaces**, same
  pattern as storage (`app/services/embeddings.py`,
  `app/services/vector_store.py`). Production uses `sentence-transformers` +
  Qdrant; tests inject a deterministic hash-based fake embedder and an
  in-memory vector store, so the full chunk → embed → search pipeline is
  unit-testable without a GPU, a model download, or a running Qdrant
  instance. The fake backend has **no semantic understanding** — it only
  guarantees identical text → identical vector — so tests that need to
  prove *ranking* correctness query with exact chunk text rather than
  paraphrases (see the docstring on `test_query_retrieves_relevant_chunk`).
- **Vector store payloads never carry chunk text**, only `tenant_id` /
  `document_id` (`chunk_id` is the point id itself). Chunk content is the
  source of truth in Postgres and is fetched by id after a vector search
  returns matches. This keeps the vector store from becoming a second
  source of truth for content.
- **Tenant isolation extends to vector search**, not just SQL. Every
  `vector_store.search()` call requires a `tenant_id` and applies it as a
  hard filter — there's no code path that can run an unfiltered or
  cross-tenant vector search. See `test_vector_store_tenant_isolation` and
  `test_query_tenant_isolation`.
- **LLM synthesis degrades gracefully.** `POST /v1/query` always performs
  real retrieval; if `ANTHROPIC_API_KEY` isn't set it returns the retrieved
  chunks with `answer_synthesized: false` instead of failing the request.
  This is also what keeps the test suite free of any dependency on a live
  API key.

## Quickstart (Docker — recommended)

```bash
docker compose up --build
```

This starts Postgres, Qdrant, and the API with hot-reload. The API is at
`http://localhost:8000`, interactive docs at `http://localhost:8000/docs`,
Qdrant's own dashboard at `http://localhost:6333/dashboard`.

The embedding model (~80MB) downloads on the API container's first startup
and is cached in a named volume afterwards, so subsequent restarts are
fast. To enable LLM answer synthesis on `/v1/query`, export a key before
starting:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
docker compose up --build
```

Without it, `/v1/query` still performs real retrieval — it just returns
`answer_synthesized: false` and `answer: null` instead of a generated
answer.

Tables are auto-created on startup for this phase (`AUTO_CREATE_TABLES=true`
in `docker-compose.yml`). From Phase 5 onward, CI/CD runs
`alembic upgrade head` as an explicit deploy step instead — the Alembic
setup is already here and working (see "Migrations" below) if you want to
use it now.

## Quickstart (without Docker)

Requires Python 3.12+ and a running Postgres instance (or just use the
SQLite default for a quick look).

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env      # edit DATABASE_URL if not using the SQLite default
uvicorn app.main:app --reload
```

## Demo script (run against either setup)

```bash
BASE=http://localhost:8000

# 1. Sign up — creates a tenant + owner user, returns a JWT
curl -s -X POST $BASE/v1/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"tenant_name":"Acme Corp","email":"demo@acme.io","password":"supersecret123"}' | tee /tmp/signup.json
TOKEN=$(python -c "import json;print(json.load(open('/tmp/signup.json'))['token']['access_token'])")

# 2. Log in (alternative to using the signup token directly)
curl -s -X POST $BASE/v1/auth/login \
  -d "username=demo@acme.io&password=supersecret123"

# 3. Upload a document
echo "Vector databases enable semantic search over unstructured text." > sample.txt
curl -s -X POST $BASE/v1/documents \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@sample.txt;type=text/plain" | tee /tmp/upload.json
DOC_ID=$(python -c "import json;print(json.load(open('/tmp/upload.json'))['id'])")

# 4. List documents
curl -s $BASE/v1/documents -H "Authorization: Bearer $TOKEN"

# 5. Get extracted content
curl -s $BASE/v1/documents/$DOC_ID/content -H "Authorization: Bearer $TOKEN"

# 6. Confirm auth is enforced
curl -s -o /dev/null -w "%{http_code}\n" $BASE/v1/documents   # -> 401

# 7. Inspect the chunks it was split into
curl -s $BASE/v1/documents/$DOC_ID/chunks -H "Authorization: Bearer $TOKEN"

# 8. Ask a question over your documents (RAG)
curl -s -X POST $BASE/v1/query \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"question": "What do my documents say about semantic search?", "top_k": 5}'
# -> real retrieved chunks always; "answer" is non-null only if
#    ANTHROPIC_API_KEY was set when the container started

# 9. Delete it
curl -s -o /dev/null -w "%{http_code}\n" -X DELETE $BASE/v1/documents/$DOC_ID \
  -H "Authorization: Bearer $TOKEN"   # -> 204
```

Or skip curl entirely and use the Swagger UI at `/docs` — click "Authorize",
paste `Bearer <token>` from the signup response, and try every endpoint
interactively.

## Running the tests

```bash
pytest -v
```

42 tests, no Docker/Postgres/Qdrant required — they run against an isolated
in-memory SQLite database, a deterministic fake embedding backend, and an
in-memory vector store per test (see `tests/conftest.py`). Covers:

- **Phase 1:** signup/login validation, JWT auth enforcement, upload +
  extraction for txt/docx, graceful handling of corrupt/unsupported files,
  dedup by content hash, pagination, deletion, tenant isolation
- **Phase 2:** chunking (overlap, coverage, edge cases), the fake embedding
  backend's determinism, the in-memory vector store's ranking/filtering/
  tenant-isolation/deletion behavior, and the full upload → chunk → embed →
  `/v1/query` pipeline end-to-end through the real API — including that
  `document_ids` scoping works, that a tenant with no documents gets an
  empty result instead of an error, and that Tenant B can't retrieve so
  much as a chunk of Tenant A's content via `/v1/query`

To sanity-check retrieval quality with the *real* embedding model instead
of the test fake, run the Docker stack and try the demo script's step 8
with a couple of documents on different topics — you should see the
correct document's chunks ranked first for an on-topic question.

## Migrations

An initial migration already exists (`alembic/versions/`). To use Alembic
instead of `AUTO_CREATE_TABLES`:

```bash
export AUTO_CREATE_TABLES=false
alembic upgrade head        # apply
alembic downgrade base      # roll back (tested — both directions work)
alembic revision --autogenerate -m "description"   # after changing models.py
```

## API surface (Phase 1)

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/v1/auth/signup` | — | Create tenant + owner user, returns JWT |
| POST | `/v1/auth/login` | — | Exchange email/password for JWT |
| POST | `/v1/documents` | JWT | Upload + synchronously extract a document |
| GET | `/v1/documents` | JWT | List tenant's documents (paginated) |
| GET | `/v1/documents/{id}` | JWT | Get one document's metadata |
| GET | `/v1/documents/{id}/content` | JWT | Get extracted text (409 if not ready) |
| GET | `/v1/documents/{id}/chunks` | JWT | Inspect how a document was chunked |
| DELETE | `/v1/documents/{id}` | JWT | Delete document + chunks + vectors + underlying file |
| POST | `/v1/query` | JWT | RAG query: retrieve relevant chunks, optionally synthesize an answer |
| GET | `/health` | — | Liveness check |

## What's deliberately *not* here yet

- Row-Level Security + explicit isolation hardening → **Phase 3**
- Async ingestion via message queue + worker, webhooks → **Phase 4**
- Observability (metrics/tracing/logging), CI/CD, Kubernetes → **Phase 5**
- Hybrid search (keyword + vector), re-ranking, usage-based billing → **Phase 6**
