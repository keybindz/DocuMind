"""
The sweeper: re-queues work that was accepted but never finished.

Two real gaps it closes (both called out in Phase 4):

  * A webhook delivery row is committed ('pending') but the broker nudge that
    should trigger it was lost -- publish failed after the commit, or Redis lost
    the message. The outbox row is durable; nothing was waking it up.
  * A document is stuck in `pending/extracting/chunking/embedding` because its
    queue message vanished (broker flushed or evicted, a worker killed in a way
    that skipped redelivery) and nothing will ever pick it up.

"Stalled" means NO PROGRESS for a threshold, measured by `updated_at` (every
pipeline stage commits, which bumps it). The threshold is deliberately long
(default 15 min): a stage that is merely slow must not look stalled, because
re-queueing a job that is actually still running makes two workers process one
document. Handlers are idempotent so that would be survivable, but it wastes
work and muddies the metrics -- so we err toward waiting.

Why it needs the SYSTEM context: finding stalled work for every tenant is
inherently cross-tenant, which Row-Level Security exists to forbid. This is one
of exactly two legitimate users of the bypass (the other is signup/login), and
a test pins that list.

Safe to run concurrently: rows are claimed with FOR UPDATE SKIP LOCKED, so two
sweepers never grab the same row, and a row is touched after being re-queued
so the next tick doesn't re-queue it again.
"""
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from app.models import Document, DocumentStatus, WebhookDelivery
from app.observability import metrics
from app.services.task_queue import QueueUnavailable, TaskQueue

logger = logging.getLogger(__name__)

IN_PROGRESS = (DocumentStatus.pending, DocumentStatus.extracting, DocumentStatus.chunking, DocumentStatus.embedding)


@dataclass
class SweepResult:
    documents: int = 0
    deliveries: int = 0


def sweep(
    db: Session,
    queue: TaskQueue,
    *,
    document_stale_seconds: int,
    delivery_stale_seconds: int,
    limit: int,
    now: datetime | None = None,
) -> SweepResult:
    """`db` must be a system-context session (see core.tenancy.system_session)."""
    now = now or datetime.now(timezone.utc)
    result = SweepResult()
    metrics.SWEEPER_RUNS.inc()

    stalled_docs = (
        db.query(Document)
        .filter(Document.status.in_(IN_PROGRESS), Document.updated_at < now - timedelta(seconds=document_stale_seconds))
        .order_by(Document.updated_at)
        .limit(limit)
        .with_for_update(skip_locked=True)
        .all()
    )
    try:
        for doc in stalled_docs:
            queue.enqueue_ingestion(doc.id, doc.tenant_id)
            doc.updated_at = now  # touched: don't pick it up again on the next tick
            result.documents += 1
    except QueueUnavailable:
        metrics.QUEUE_PUBLISH_FAILURES.inc()
        logger.warning("Sweeper could not reach the broker; leaving remaining documents for the next run")
    db.commit()

    stalled_deliveries = (
        db.query(WebhookDelivery)
        .filter(WebhookDelivery.status == "pending", WebhookDelivery.updated_at < now - timedelta(seconds=delivery_stale_seconds))
        .order_by(WebhookDelivery.updated_at)
        .limit(limit)
        .with_for_update(skip_locked=True)
        .all()
    )
    try:
        for delivery in stalled_deliveries:
            queue.enqueue_webhook_delivery(delivery.id, delivery.tenant_id)
            delivery.updated_at = now
            result.deliveries += 1
    except QueueUnavailable:
        metrics.QUEUE_PUBLISH_FAILURES.inc()
        logger.warning("Sweeper could not reach the broker; leaving remaining deliveries for the next run")
    db.commit()

    if result.documents:
        metrics.SWEEPER_REQUEUED.labels("document").inc(result.documents)
    if result.deliveries:
        metrics.SWEEPER_REQUEUED.labels("webhook_delivery").inc(result.deliveries)
    if result.documents or result.deliveries:
        # Anything here means something upstream lost a message: worth noticing.
        logger.warning("Sweeper re-queued stalled work", extra={"documents": result.documents, "deliveries": result.deliveries})
    return result
