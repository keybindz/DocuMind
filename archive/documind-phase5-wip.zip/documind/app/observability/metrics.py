"""
Prometheus metrics.

Naming follows Prometheus conventions: `documind_` prefix, base units
(seconds), `_total` on counters.

LABEL DISCIPLINE -- the rule that keeps Prometheus alive: label values come
from small, fixed sets (HTTP method, route TEMPLATE, status code, an outcome
enum). Never tenant ids, document ids, URLs or user input: every distinct
label value creates a new time series, and an unbounded label is how a metrics
system gets taken down by its own success. Per-tenant usage is a billing/
analytics concern and belongs in the database (Phase 6 `usage_events`).

The API process serves these on GET /metrics; the Celery worker has no HTTP
server, so it starts its own on WORKER_METRICS_PORT (app/worker/celery_app.py).
Each process exposes only its own counters, and Prometheus scrapes both.
"""
import logging
import threading

from prometheus_client import REGISTRY, Counter, Gauge, Histogram
from prometheus_client.core import GaugeMetricFamily

logger = logging.getLogger(__name__)

_HTTP_BUCKETS = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10)
_JOB_BUCKETS = (0.01, 0.05, 0.1, 0.5, 1, 2.5, 5, 10, 30, 60, 120, 300)
_E2E_BUCKETS = (1, 5, 10, 30, 60, 120, 300, 600, 1800, 3600)

# ---- HTTP (API process) ----
HTTP_REQUESTS = Counter(
    "documind_http_requests_total", "HTTP requests handled", ["method", "route", "status"]
)
HTTP_DURATION = Histogram(
    "documind_http_request_duration_seconds", "HTTP request latency", ["method", "route"], buckets=_HTTP_BUCKETS
)
HTTP_IN_PROGRESS = Gauge("documind_http_requests_in_progress", "HTTP requests currently being handled")

# ---- Ingestion (worker process) ----
INGESTION_JOBS = Counter(
    "documind_ingestion_jobs_total",
    "Ingestion job attempts by outcome (ready | failed_permanent | failed_exhausted | retry | skipped)",
    ["outcome"],
)
INGESTION_STAGE_DURATION = Histogram(
    "documind_ingestion_stage_duration_seconds",
    "Time spent in each ingestion stage (extract | chunk | embed)",
    ["stage"],
    buckets=_JOB_BUCKETS,
)
TIME_TO_READY = Histogram(
    "documind_document_time_to_ready_seconds",
    "Upload-to-ready latency: the number users actually feel",
    buckets=_E2E_BUCKETS,
)

# ---- Webhooks (worker process) ----
WEBHOOK_DELIVERIES = Counter(
    "documind_webhook_deliveries_total",
    "Webhook delivery attempts by outcome (succeeded | retry | failed)",
    ["outcome"],
)
WEBHOOK_DURATION = Histogram(
    "documind_webhook_delivery_duration_seconds",
    "Latency of the outbound HTTP call to a customer endpoint",
    buckets=(0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10),
)

# ---- Protection layers (API process) ----
RATE_LIMIT_REJECTIONS = Counter(
    "documind_rate_limit_rejections_total", "Requests rejected with 429", ["action"]
)
QUOTA_REJECTIONS = Counter("documind_quota_rejections_total", "Requests rejected for plan quota", ["kind"])
QUEUE_PUBLISH_FAILURES = Counter(
    "documind_queue_publish_failures_total", "Times the broker was unreachable when enqueueing work"
)

# ---- Search (API process) ----
QUERIES = Counter("documind_queries_total", "RAG queries by whether an LLM answer was synthesized", ["synthesized"])
QUERY_DURATION = Histogram(
    "documind_query_duration_seconds", "End-to-end /v1/query latency", buckets=_HTTP_BUCKETS + (30,)
)

# ---- Sweeper (worker process) ----
SWEEPER_REQUEUED = Counter(
    "documind_sweeper_requeued_total", "Stalled work re-queued by the sweeper (document | webhook_delivery)", ["kind"]
)
SWEEPER_RUNS = Counter("documind_sweeper_runs_total", "Sweeper executions")

QUEUE_DEPTH_SCRAPE_ERRORS = Counter(
    "documind_queue_depth_scrape_errors_total", "Failed attempts to read the broker queue depth at scrape time"
)


class QueueDepthCollector:
    """
    Reads the Celery queue length from Redis at SCRAPE time (a gauge sampled
    when asked, not a number we try to keep updated). This is the same figure
    KEDA autoscales the worker on, so the dashboard shows exactly what the
    autoscaler sees. If Redis is unreachable the sample is omitted rather than
    reported as 0, because "0 jobs waiting" and "can't tell" are very different.
    """

    def __init__(self, broker_url: str, queue_name: str = "celery"):
        import redis

        self._queue = queue_name
        self._client = redis.Redis.from_url(broker_url, socket_timeout=0.5, socket_connect_timeout=0.5)
        self._redis_error = redis.RedisError

    def collect(self):
        family = GaugeMetricFamily("documind_queue_depth", "Jobs waiting in the broker queue", labels=["queue"])
        try:
            family.add_metric([self._queue], float(self._client.llen(self._queue)))
        except self._redis_error:
            QUEUE_DEPTH_SCRAPE_ERRORS.inc()
            logger.warning("Could not read queue depth from the broker", exc_info=True)
        yield family


_collector_lock = threading.Lock()
_collector: QueueDepthCollector | None = None


def register_queue_depth_collector(broker_url: str) -> None:
    """Idempotent; the API calls this once at startup."""
    global _collector
    with _collector_lock:
        if _collector is None:
            _collector = QueueDepthCollector(broker_url)
            REGISTRY.register(_collector)


def sample(name: str, labels: dict | None = None) -> float:
    """Current value of a metric sample (0.0 if it has never been recorded). For tests and diagnostics."""
    value = REGISTRY.get_sample_value(name, labels or {})
    return 0.0 if value is None else value
