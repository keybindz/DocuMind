"""
OpenTelemetry tracing.

Off by default (OTEL_EXPORTER=none): the API calls then return no-op spans, so
instrumented code costs nothing when tracing is disabled.

When on, one trace spans the whole upload: the HTTP request in the API, its
SQL queries, the publish to the broker, and -- because the Celery
instrumentation injects the W3C `traceparent` header into the task message --
the ingestion job and webhook delivery in a different process. That is what
turns "the upload felt slow" into "the embedding stage took 11s on worker-2".

Span attributes carry ids (document, tenant) because traces tolerate high
cardinality; metrics labels do not (see metrics.py). Never put file contents,
tokens, or webhook secrets in span attributes.
"""
import logging
import threading

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter, SimpleSpanProcessor

from app.config import get_settings

logger = logging.getLogger(__name__)
_lock = threading.Lock()
_provider: TracerProvider | None = None
_instrumented: set[str] = set()


def get_tracer():
    return trace.get_tracer("documind")


def setup_tracing(service_name: str, *, span_exporter=None) -> TracerProvider | None:
    """
    Idempotent. Returns the active provider, or None when tracing is disabled.
    `span_exporter` lets tests inject an in-memory exporter.
    """
    global _provider
    settings = get_settings()
    with _lock:
        if _provider is not None:
            return _provider
        processor = None
        if span_exporter is not None:
            processor = SimpleSpanProcessor(span_exporter)
        elif settings.OTEL_EXPORTER == "console":
            processor = SimpleSpanProcessor(ConsoleSpanExporter())
        elif settings.OTEL_EXPORTER == "otlp":
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

            processor = BatchSpanProcessor(OTLPSpanExporter())  # endpoint/headers come from standard OTEL_* env vars
        if processor is None:
            return None

        provider = TracerProvider(resource=Resource.create({"service.name": service_name, "deployment.environment": settings.ENV}))
        provider.add_span_processor(processor)
        trace.set_tracer_provider(provider)
        _provider = provider
        _instrument_libraries()
        logger.info("Tracing enabled (exporter=%s)", "injected" if span_exporter else settings.OTEL_EXPORTER)
        return provider


def _instrument_libraries() -> None:
    from opentelemetry.instrumentation.celery import CeleryInstrumentor
    from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
    from opentelemetry.instrumentation.sqlalchemy import SQLAlchemyInstrumentor

    from app.database import engine

    if "sqlalchemy" not in _instrumented:
        SQLAlchemyInstrumentor().instrument(engine=engine)
        _instrumented.add("sqlalchemy")
    if "httpx" not in _instrumented:
        HTTPXClientInstrumentor().instrument()
        _instrumented.add("httpx")
    if "celery" not in _instrumented:
        CeleryInstrumentor().instrument()  # injects/extracts traceparent on task publish/run
        _instrumented.add("celery")


def instrument_fastapi(app) -> None:
    """
    Safe to call from the startup lifespan, i.e. AFTER Starlette has built the
    middleware stack. Starlette refuses `add_middleware` once that has happened
    (`RuntimeError: Cannot add middleware after an application has started`),
    and the OpenTelemetry instrumentor works by adding middleware -- so the stack
    is reset first and rebuilt after. Requests arriving later use the new stack.
    """
    from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

    with _lock:
        if _provider is None or "fastapi" in _instrumented:
            return
        app.middleware_stack = None  # allow add_middleware on an already-started app
        FastAPIInstrumentor.instrument_app(
            app, excluded_urls="health,ready,metrics"  # probes and scrapes would drown real traces
        )
        app.middleware_stack = app.build_middleware_stack()
        _instrumented.add("fastapi")
