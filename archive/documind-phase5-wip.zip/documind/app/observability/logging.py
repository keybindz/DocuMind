"""
Structured (JSON) logging with automatic request/job context.

Every log line is one JSON object, so a log pipeline (Loki, CloudWatch,
Elastic) can filter on fields instead of regex-ing prose. Context -- request
id, tenant id, document id, Celery task id -- lives in `contextvars`, so any
code anywhere in a request or job gets those fields on its log lines without
having them passed down. When a trace is active, `trace_id`/`span_id` are
added too, which is what lets you jump from a log line to its trace.

What must never appear in logs: secrets, tokens, file contents. Nothing in
this codebase logs them, and as a backstop the formatter redacts any field
whose NAME looks sensitive (see `_SENSITIVE`) -- defense against a future
`logger.info("...", extra={"password": ...})`, not a license to log secrets.
"""
import contextvars
import json
import logging
import re
import sys
from contextlib import contextmanager
from datetime import datetime, timezone

from opentelemetry import trace

# The context is a MUTABLE dict held in a ContextVar, mutated in place -- not a
# ContextVar value that is re-assigned. FastAPI runs sync dependencies and sync
# route handlers in a thread pool, and a thread-pool call receives a COPY of the
# calling context: re-assigning the ContextVar there would be invisible to the
# middleware and to later calls. Mutating a dict that every copy still points to
# is what makes `bind_context(tenant_id=...)` inside a dependency show up on the
# access log line and on every log line the route handler emits afterwards.
_context: contextvars.ContextVar[dict | None] = contextvars.ContextVar("log_context", default=None)

_SENSITIVE = re.compile(r"(authorization|password|passwd|secret|token|api[_-]?key|cookie|signature)", re.I)
_STANDARD_RECORD_ATTRS = set(logging.LogRecord("", 0, "", 0, "", (), None).__dict__) | {"message", "asctime", "taskName"}


def bind_context(**fields) -> None:
    """Attach fields to every log line emitted in the current request/job."""
    ctx = _context.get()
    if ctx is None:
        ctx = {}
        _context.set(ctx)
    ctx.update({k: v for k, v in fields.items() if v is not None})


def clear_context() -> None:
    """Start a fresh context (new dict) -- called at the start and end of each request/task."""
    _context.set({})


def get_context() -> dict:
    return dict(_context.get() or {})


@contextmanager
def log_context(**fields):
    """Bind fields for the duration of a block, then restore the previous values."""
    bind_context()  # make sure a dict exists to mutate
    ctx = _context.get()
    previous = dict(ctx)
    ctx.update({k: v for k, v in fields.items() if v is not None})
    try:
        yield
    finally:
        ctx.clear()
        ctx.update(previous)


def _redact(key: str, value):
    return "[REDACTED]" if _SENSITIVE.search(key) else value


class JsonFormatter(logging.Formatter):
    def __init__(self, service: str):
        super().__init__()
        self.service = service

    def format(self, record: logging.LogRecord) -> str:
        entry = {
            "ts": datetime.fromtimestamp(record.created, timezone.utc).isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "logger": record.name,
            "service": self.service,
            "message": record.getMessage(),
        }
        for key, value in (_context.get() or {}).items():
            entry[key] = _redact(key, value)
        span_context = trace.get_current_span().get_span_context()
        if span_context.is_valid:
            entry["trace_id"] = format(span_context.trace_id, "032x")
            entry["span_id"] = format(span_context.span_id, "016x")
        for key, value in record.__dict__.items():  # fields passed via `extra=`
            if key not in _STANDARD_RECORD_ATTRS and key not in entry:
                entry[key] = _redact(key, value)
        if record.exc_info:
            entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(entry, default=str)


class ConsoleFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        context = " ".join(f"{k}={v}" for k, v in (_context.get() or {}).items())
        base = f"{datetime.fromtimestamp(record.created):%H:%M:%S} {record.levelname:<7} {record.name}: {record.getMessage()}"
        text = f"{base}  [{context}]" if context else base
        return text + ("\n" + self.formatException(record.exc_info) if record.exc_info else "")


def configure_logging(service: str, *, level: str = "INFO", fmt: str = "json", stream=None) -> None:
    """Idempotent: replaces the root handlers so repeated calls never duplicate output."""
    handler = logging.StreamHandler(stream or sys.stdout)
    handler.setFormatter(JsonFormatter(service) if fmt == "json" else ConsoleFormatter())
    handler.set_name("documind")
    root = logging.getLogger()
    root.handlers = [h for h in root.handlers if h.get_name() != "documind"] + [handler]
    root.setLevel(level.upper())

    # uvicorn's own access log is replaced by our structured per-request line
    # (which carries route, status, duration and request id); its error log
    # flows through the root handler like everything else.
    logging.getLogger("uvicorn.access").handlers = []
    logging.getLogger("uvicorn.access").propagate = False
    # httpx logs every outbound request URL at INFO. Our outbound calls are
    # customers' webhook URLs, which routinely carry secret tokens in the query
    # string -- they must not land in our logs.
    for name in ("httpx", "httpcore"):
        logging.getLogger(name).setLevel(logging.WARNING)
    for name in ("uvicorn", "uvicorn.error", "celery", "celery.app.trace", "celery.worker"):
        logging.getLogger(name).handlers = []
        logging.getLogger(name).propagate = True
