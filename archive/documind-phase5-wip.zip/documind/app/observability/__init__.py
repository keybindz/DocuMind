"""Observability: structured logs, Prometheus metrics, OpenTelemetry traces, health checks."""
