"""
One ASGI middleware does three jobs for every HTTP request:

  1. REQUEST ID: honor a sane inbound `X-Request-ID` (so a request can be
     followed across a load balancer / another service) or mint one; bind it to
     the log context; echo it on the response.
  2. METRICS: count and time the request, labelled by route TEMPLATE
     (`/v1/documents/{document_id}`), never the raw path, so ids in URLs can't
     explode label cardinality.
  3. ACCESS LOG: one structured line per request with route, status, duration.

It is a plain ASGI middleware rather than Starlette's BaseHTTPMiddleware,
which wraps the response body in a stream and is known to interfere with
background tasks and contextvars.
"""
import logging
import re
import time
import uuid

from app.observability import metrics
from app.observability.logging import bind_context, clear_context

logger = logging.getLogger("documind.access")

_VALID_REQUEST_ID = re.compile(r"^[A-Za-z0-9._-]{1,64}$")  # rejects newlines etc.: no log injection via the header
_QUIET_PATHS = {"/health", "/ready", "/metrics"}  # probes/scrapes every few seconds would drown real traffic in logs


class ObservabilityMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)

        headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope["headers"]}
        inbound = headers.get("x-request-id", "")
        request_id = inbound if _VALID_REQUEST_ID.match(inbound) else uuid.uuid4().hex

        clear_context()
        bind_context(request_id=request_id)
        method = scope["method"]
        status_holder = {"status": 500}  # stays 500 if the app raises before responding
        started = time.perf_counter()
        metrics.HTTP_IN_PROGRESS.inc()

        async def send_wrapper(message):
            if message["type"] == "http.response.start":
                status_holder["status"] = message["status"]
                message["headers"] = [*message.get("headers", []), (b"x-request-id", request_id.encode())]
            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            elapsed = time.perf_counter() - started
            metrics.HTTP_IN_PROGRESS.dec()
            route = scope.get("route")
            route_label = getattr(route, "path", None) or "unmatched"  # template, set by the router
            status = status_holder["status"]
            metrics.HTTP_REQUESTS.labels(method, route_label, str(status)).inc()
            metrics.HTTP_DURATION.labels(method, route_label).observe(elapsed)
            if scope["path"] not in _QUIET_PATHS or status >= 500:
                logger.info(
                    "%s %s -> %s",
                    method,
                    route_label,
                    status,
                    extra={"http_method": method, "route": route_label, "status": status, "duration_ms": round(elapsed * 1000, 1)},
                )
            clear_context()
