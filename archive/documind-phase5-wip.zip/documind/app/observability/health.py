"""
Liveness vs readiness -- two different questions, deliberately answered differently.

  GET /health  LIVENESS.  "Is this process wedged?"  Checks NOTHING external.
               If it checked the database, a database outage would make
               Kubernetes restart every API pod at once, turning a dependency
               problem into a full outage plus a thundering herd on recovery.

  GET /ready   READINESS. "Should traffic be routed to me right now?"  Checks
               the dependencies this pod needs to serve a request. Failing it
               removes the pod from the Service (no restart); it rejoins when
               the dependency recovers.

Responses name WHICH dependency is down but never include exception text,
which can leak hostnames, usernames or connection strings to anyone who can
reach the endpoint.
"""
import logging
from typing import Callable

from sqlalchemy import text
from sqlalchemy.orm import Session

from app.config import get_settings

logger = logging.getLogger(__name__)

Check = Callable[[Session], None]  # raises on failure


def check_database(db: Session) -> None:
    db.execute(text("SELECT 1"))


def check_broker(db: Session) -> None:
    import redis

    client = redis.Redis.from_url(get_settings().CELERY_BROKER_URL, socket_timeout=1, socket_connect_timeout=1)
    client.ping()


def default_checks() -> dict[str, Check]:
    checks: dict[str, Check] = {"database": check_database}
    if get_settings().TASK_QUEUE_BACKEND == "celery":
        checks["broker"] = check_broker
    return checks


def run_checks(db: Session, checks: dict[str, Check]) -> dict[str, str]:
    results = {}
    for name, check in checks.items():
        try:
            check(db)
            results[name] = "ok"
        except Exception:  # noqa: BLE001 - any failure means "not ready"; details go to logs, not the response
            logger.warning("Readiness check failed: %s", name, exc_info=True)
            results[name] = "unavailable"
    return results
