import hmac
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, HTTPException, Request, Response, status
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import Base, engine, get_db
from app.observability import health as health_checks
from app.observability.logging import configure_logging
from app.observability.metrics import register_queue_depth_collector
from app.observability.middleware import ObservabilityMiddleware
from app.observability.tracing import instrument_fastapi, setup_tracing
from app.routers import auth, documents, query, tenant, webhooks

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Dev/test convenience only. Real environments run `alembic upgrade head`
    # as a deploy step instead — see alembic/README in this repo.
    configure_logging("documind-api", level=settings.LOG_LEVEL, fmt=settings.LOG_FORMAT)
    setup_tracing("documind-api")
    instrument_fastapi(app)
    if settings.METRICS_ENABLED and settings.TASK_QUEUE_BACKEND == "celery":
        register_queue_depth_collector(settings.CELERY_BROKER_URL)
    if settings.AUTO_CREATE_TABLES:
        Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(
    title=settings.APP_NAME,
    version="0.1.0",
    description="Multi-tenant document intelligence platform — Phases 1-4 (auth, async ingestion, RAG, tenancy, webhooks).",
    lifespan=lifespan,
)


app.add_middleware(ObservabilityMiddleware)


@app.get("/health", tags=["meta"])
def health():
    """Liveness: is the process alive? Deliberately checks no dependency (see observability/health.py)."""
    return {"status": "ok", "app": settings.APP_NAME, "env": settings.ENV}


def get_readiness_checks() -> dict:
    return health_checks.default_checks()


@app.get("/ready", tags=["meta"])
def ready(
    response: Response,
    db: Session = Depends(get_db),
    checks: dict = Depends(get_readiness_checks),
):
    """Readiness: can this pod serve traffic right now? 503 takes it out of the Service without restarting it."""
    results = health_checks.run_checks(db, checks)
    healthy = all(v == "ok" for v in results.values())
    if not healthy:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return {"status": "ready" if healthy else "unavailable", "checks": results}


@app.get("/metrics", tags=["meta"], include_in_schema=False)
def metrics_endpoint(request: Request):
    if not settings.METRICS_ENABLED:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    token = settings.METRICS_AUTH_TOKEN
    if token:
        supplied = request.headers.get("authorization", "")
        if not hmac.compare_digest(supplied.encode(), f"Bearer {token}".encode()):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, headers={"WWW-Authenticate": "Bearer"})
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


app.include_router(auth.router)
app.include_router(documents.router)
app.include_router(query.router)
app.include_router(tenant.router)
app.include_router(webhooks.router)
