"""
Celery application for the background worker.

Run with:  celery -A app.worker.celery_app worker --loglevel=info

Reliability settings, and why:

- task_acks_late + task_reject_on_worker_lost: a task is acknowledged only
  AFTER it finishes, and is redelivered if the worker process dies mid-task.
  That gives at-least-once delivery -- which is why every handler is
  idempotent (see services/pipeline.py).
- worker_prefetch_multiplier=1: a worker takes one task at a time. With long
  ingestion jobs and acks_late, prefetching would let one slow job strand a
  queue of tasks behind it on a single worker.
- visibility_timeout (Redis transport): if a task isn't acked within this
  window Redis redelivers it to another worker. It must exceed the longest
  retry countdown (webhook backoff is capped at 1h), or delayed tasks would
  be delivered twice.
- No result backend: job state lives in Postgres (document.status,
  webhook_deliveries), which is queryable and tenant-scoped. A result backend
  would be a second, unscoped source of truth.
"""
import logging
import threading

from celery import Celery
from celery.signals import setup_logging, task_postrun, task_prerun, worker_process_init, worker_ready

from app.config import get_settings
from app.observability.logging import bind_context, clear_context, configure_logging
from app.observability.tracing import setup_tracing

settings = get_settings()
logger = logging.getLogger(__name__)

celery_app = Celery("documind", broker=settings.CELERY_BROKER_URL, include=["app.worker.tasks"])
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    task_ignore_result=True,
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    worker_prefetch_multiplier=1,
    broker_connection_retry_on_startup=True,
    broker_transport_options={"visibility_timeout": 7200},
    timezone="UTC",
    # We configure logging ourselves (JSON, with request/job context); don't let
    # Celery replace the root logger's handlers with its own format.
    worker_hijack_root_logger=False,
)

if settings.SWEEPER_ENABLED:
    # Run exactly ONE beat process (the K8s manifest pins it to 1 replica with
    # strategy Recreate). Two would double-fire; the sweeper tolerates that
    # (row locks + idempotent handlers) but it's wasted work.
    celery_app.conf.beat_schedule = {
        "sweep-stalled-work": {"task": "documind.sweep", "schedule": float(settings.SWEEP_INTERVAL_SECONDS)},
    }


@setup_logging.connect  # connecting a receiver tells Celery NOT to set up its own logging
def _configure_worker_logging(**_):
    configure_logging("documind-worker", level=settings.LOG_LEVEL, fmt=settings.LOG_FORMAT)


@task_prerun.connect
def _bind_task_context(task_id=None, task=None, **_):
    clear_context()
    bind_context(task_id=task_id, task=getattr(task, "name", None))


@task_postrun.connect
def _clear_task_context(**_):
    clear_context()


_metrics_started = threading.Event()


def _start_metrics_server() -> None:
    """
    A Celery worker has no HTTP server, so serve /metrics from a side thread.
    Counters live in this process's memory, which is why the worker is run with
    `--pool=threads` (one process, many threads) rather than prefork: under
    prefork each child would keep its own counters and the scraped main process
    would see none of them (prometheus_client's multiprocess mode is the
    alternative, at the cost of a shared metrics directory to manage).
    """
    if settings.WORKER_METRICS_PORT and not _metrics_started.is_set():
        from prometheus_client import start_http_server

        start_http_server(settings.WORKER_METRICS_PORT)
        _metrics_started.set()
        logger.info("Worker metrics listening on :%d", settings.WORKER_METRICS_PORT)


@worker_process_init.connect  # prefork children
def _init_child(**_):
    setup_tracing("documind-worker")


@worker_ready.connect  # main process: where threads/solo pools actually run tasks
def _init_main(**_):
    setup_tracing("documind-worker")
    _start_metrics_server()
