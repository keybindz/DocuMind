"""OpenTelemetry spans: structure, parenting, and what must never be recorded."""
import json

import pytest
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from app.main import app
from app.observability.tracing import instrument_fastapi, setup_tracing


@pytest.fixture(scope="module")
def exporter():
    from fastapi.testclient import TestClient

    # Reproduce the PRODUCTION order deterministically: the app has already
    # started (the real instrumentation runs inside the startup lifespan)
    # before tracing is switched on. Relying on test ordering for this hid a
    # crash ("Cannot add middleware after an application has started").
    with TestClient(app) as started:
        started.get("/health")
        assert app.middleware_stack is not None
        exp = InMemorySpanExporter()
        assert setup_tracing("documind-test", span_exporter=exp) is not None
        instrument_fastapi(app)
    return exp


@pytest.fixture()
def spans(exporter):
    exporter.clear()
    return lambda: exporter.get_finished_spans()


def _signup(client, name="Alpha"):
    r = client.post(
        "/v1/auth/signup",
        json={"tenant_name": name, "email": f"o@{name.lower()}.io", "password": "supersecret123"},
    )
    return {"Authorization": f"Bearer {r.json()['token']['access_token']}"}


def _upload(client, headers, text="tracing test content"):
    return client.post("/v1/documents", headers=headers, files={"file": ("a.txt", text.encode(), "text/plain")})


def _by_name(spans, name):
    return [s for s in spans if s.name == name]


def test_one_trace_covers_the_request_and_every_ingestion_stage(client, spans):
    headers = _signup(client)
    client_spans_before = {s.context.span_id for s in spans()}
    _upload(client, headers)

    finished = [s for s in spans() if s.context.span_id not in client_spans_before]
    (server,) = [s for s in finished if s.name == "POST /v1/documents"]
    (job,) = _by_name(finished, "ingest.job")
    stages = {s.name: s for s in finished if s.name.startswith("ingest.") and s.name != "ingest.job"}

    assert set(stages) == {"ingest.extract", "ingest.chunk", "ingest.embed"}
    assert all(s.parent.span_id == job.context.span_id for s in stages.values())  # stages nest under the job
    assert {s.context.trace_id for s in [server, job, *stages.values()]} == {server.context.trace_id}  # ONE trace
    assert job.attributes["documind.attempt"] == 1
    assert server.attributes["http.route"] == "/v1/documents"  # the template, not a concrete path


def test_webhook_delivery_is_part_of_the_same_trace(client, spans, webhook_sender):
    headers = _signup(client)
    client.post("/v1/webhooks", headers=headers, json={"url": "http://127.0.0.1:9/hook"})
    before = {s.context.span_id for s in spans()}
    _upload(client, headers)

    finished = [s for s in spans() if s.context.span_id not in before]
    (server,) = [s for s in finished if s.name == "POST /v1/documents"]
    (deliver,) = _by_name(finished, "webhook.deliver")
    (send,) = _by_name(finished, "webhook.send")
    assert send.parent.span_id == deliver.context.span_id
    assert deliver.context.trace_id == server.context.trace_id
    assert send.attributes["documind.event"] == "document.ready"


def test_query_steps_are_child_spans_of_the_request(client, spans):
    headers = _signup(client)
    _upload(client, headers)
    before = {s.context.span_id for s in spans()}
    client.post("/v1/query", headers=headers, json={"question": "tracing", "top_k": 3})

    finished = [s for s in spans() if s.context.span_id not in before]
    (server,) = [s for s in finished if s.name == "POST /v1/query"]
    steps = {s.name: s for s in finished if s.name.startswith("query.")}
    assert set(steps) == {"query.embed", "query.vector_search", "query.synthesize"}
    assert all(s.context.trace_id == server.context.trace_id for s in steps.values())
    assert steps["query.vector_search"].attributes["documind.top_k"] == 3


def test_probes_and_scrapes_do_not_generate_traces(client, spans):
    before = {s.context.span_id for s in spans()}
    for path in ("/health", "/ready", "/metrics"):
        client.get(path)
    new = [s for s in spans() if s.context.span_id not in before]
    assert [s.name for s in new if any(p in s.name for p in ("health", "ready", "metrics"))] == []


def test_no_secrets_tokens_or_file_contents_are_recorded_in_spans(client, spans):
    """Spans are exported to a third-party backend. Anything in an attribute leaves our trust boundary."""
    headers = _signup(client)
    bearer = headers["Authorization"].split()[1]
    created = client.post("/v1/webhooks", headers=headers, json={"url": "http://127.0.0.1:9/hook"}).json()
    _upload(client, headers, text="CANARY-FILE-CONTENT-8841")
    client.post("/v1/query", headers=headers, json={"question": "CANARY-QUESTION-5521"})

    dump = json.dumps([dict(s.attributes) for s in spans()], default=str) + json.dumps(
        [[dict(e.attributes) for e in s.events] for s in spans()], default=str
    )
    for canary in (bearer, created["secret"], "CANARY-FILE-CONTENT-8841", "supersecret123"):
        assert canary not in dump, f"{canary[:14]}... leaked into span data"


def test_sql_spans_record_the_statement_but_not_bound_parameter_values():
    """We rely on the SQLAlchemy instrumentation's default of not capturing parameters. Pin it."""
    from opentelemetry.instrumentation.sqlalchemy import SQLAlchemyInstrumentor
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor
    from sqlalchemy import create_engine, text

    from app.database import engine as app_engine

    exp = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exp))
    test_engine = create_engine("sqlite://")
    instrumentor = SQLAlchemyInstrumentor()
    instrumentor.uninstrument()  # it's a process-wide singleton, already armed by setup_tracing for the app engine
    instrumentor.instrument(engine=test_engine, tracer_provider=provider)
    try:
        with test_engine.connect() as conn:
            conn.execute(text("SELECT :v"), {"v": "CANARY-PASSWORD-HASH-7731"})
    finally:
        instrumentor.uninstrument()
        instrumentor.instrument(engine=app_engine)  # restore what setup_tracing configured
    recorded = exp.get_finished_spans()
    assert recorded, "no SQL span recorded"
    assert "SELECT" in json.dumps([dict(s.attributes) for s in recorded], default=str)  # the statement IS recorded
    assert "CANARY-PASSWORD-HASH-7731" not in json.dumps([dict(s.attributes) for s in recorded], default=str)
