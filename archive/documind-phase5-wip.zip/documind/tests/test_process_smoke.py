"""
A real `uvicorn` process with tracing ON, started the way production starts it.

This is the test that would have caught `instrument_fastapi` crashing at startup
(Starlette refuses to add middleware to a started app): in-process tests with
TestClient don't exercise the real startup sequence with an exporter enabled.
Needs no external services (SQLite + in-memory backends).
"""
import json
import os
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx
import pytest

ROOT = Path(__file__).resolve().parent.parent


def _free_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


class SimpleServer:
    def __init__(self, base, proc, log_path):
        self.base, self.proc, self.log_path = base, proc, log_path

    def log_text(self):
        return self.log_path.read_text()

    def json_logs(self):
        entries = []
        for line in self.log_text().splitlines():
            try:
                entry = json.loads(line)
            except ValueError:
                continue  # pretty-printed span output from the console exporter
            if isinstance(entry, dict) and "logger" in entry:
                entries.append(entry)
        return entries


@pytest.fixture()
def server(tmp_path):
    port = _free_port()
    log_path = tmp_path / "uvicorn.log"
    env = {
        **os.environ,
        "PYTHONPATH": str(ROOT),
        "DATABASE_URL": f"sqlite:///{tmp_path}/smoke.db",
        "AUTO_CREATE_TABLES": "true",
        "TASK_QUEUE_BACKEND": "memory",  # readiness then checks only the database
        "RATE_LIMIT_BACKEND": "memory",
        "VECTOR_STORE_BACKEND": "memory",
        "EMBEDDING_BACKEND": "fake",
        "EMBEDDING_DIMENSION": "32",
        "STORAGE_DIR": str(tmp_path / "storage"),
        "OTEL_EXPORTER": "console",
        "LOG_FORMAT": "json",
    }
    for var in ("MIGRATION_DATABASE_URL", "CELERY_BROKER_URL"):
        env.pop(var, None)
    with open(log_path, "w") as log:
        proc = subprocess.Popen(
            [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", str(port)],
            cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
        )
    base = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        assert proc.poll() is None, f"server died during startup:\n{log_path.read_text()[-3000:]}"
        try:
            if httpx.get(f"{base}/health", timeout=1).status_code == 200:
                break
        except httpx.HTTPError:
            time.sleep(0.2)
    else:
        proc.kill()
        raise AssertionError(f"server never became healthy:\n{log_path.read_text()[-3000:]}")
    yield SimpleServer(base, proc, log_path)
    if proc.poll() is None:
        proc.send_signal(signal.SIGTERM)
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()


def _token(server, email):
    r = httpx.post(
        f"{server.base}/v1/auth/signup",
        json={"tenant_name": "Smoke", "email": email, "password": "supersecret123"},
    )
    return r.json()["token"]["access_token"]


def test_server_starts_with_tracing_enabled_and_instruments_requests(server):
    token = _token(server, "smoke@acme.io")
    r = httpx.get(f"{server.base}/v1/tenant", headers={"Authorization": f"Bearer {token}", "X-Request-ID": "smoke-1"})
    assert r.status_code == 200 and r.headers["x-request-id"] == "smoke-1"
    httpx.get(f"{server.base}/health")
    time.sleep(0.5)  # let the console exporter flush

    out = server.log_text()
    assert '"name": "GET /v1/tenant"' in out  # a real server span for the request
    assert '"name": "GET /health"' not in out  # probes are excluded from tracing


def test_logs_and_traces_are_joined_by_trace_id(server):
    token = _token(server, "smoke2@acme.io")
    httpx.get(f"{server.base}/v1/tenant", headers={"Authorization": f"Bearer {token}", "X-Request-ID": "join-me"})
    time.sleep(0.5)

    access = [e for e in server.json_logs() if e.get("request_id") == "join-me" and e.get("route") == "/v1/tenant"]
    assert len(access) == 1
    assert "trace_id" in access[0], "access log line has no trace id"
    assert f'"trace_id": "0x{access[0]["trace_id"]}"' in server.log_text()  # the same id appears on the exported span


def test_probes_and_metrics_work_on_the_real_server(server):
    ready = httpx.get(f"{server.base}/ready")
    assert ready.status_code == 200 and ready.json()["checks"] == {"database": "ok"}
    metrics = httpx.get(f"{server.base}/metrics").text
    assert 'documind_http_requests_total{method="GET",route="/health",status="200"}' in metrics
    assert "documind_http_request_duration_seconds_bucket" in metrics


def test_sigterm_shuts_the_server_down_gracefully(server):
    """
    What Kubernetes sends on a rollout. Graceful = uvicorn stops accepting
    connections, lets in-flight requests finish, and runs the app's shutdown
    hooks. NOTE: uvicorn >= 0.29 re-raises the captured signal once it has shut
    down, so a graceful exit reports -SIGTERM (-15), not 0 -- the proof of a
    graceful stop is the shutdown sequence in the log and the absence of SIGKILL.
    """
    server.proc.send_signal(signal.SIGTERM)
    code = server.proc.wait(timeout=15)
    assert code in (0, -signal.SIGTERM), f"exited with {code}"  # -9 (SIGKILL) would mean it had to be force-killed
    log = server.log_text()
    for step in ("Shutting down", "Application shutdown complete", "Finished server process"):
        assert step in log, f"missing shutdown step: {step}"
