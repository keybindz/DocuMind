"""
Guards against dependency drift in the messaging stack.

`celery` was pinned but its transitive `kombu` was not, so a fresh `pip install`
months later resolved a kombu that demands a newer redis-py than we pin -- and
the worker died at startup with `VersionMismatch`. Every test using an in-memory
queue still passed, because none of them load the real Redis transport. This test
loads it.
"""
import pytest


def test_the_celery_redis_transport_is_compatible_with_the_pinned_redis_client():
    from kombu import Connection
    from kombu.exceptions import VersionMismatch

    # Nothing listens on port 1, so this can only fail with a CONNECTION error --
    # unless the library versions are incompatible, in which case kombu raises
    # VersionMismatch while constructing the channel, before it ever dials out.
    with pytest.raises(Exception) as caught:
        with Connection("redis://127.0.0.1:1/0", connect_timeout=1) as conn:
            conn.default_channel  # noqa: B018 - touching it builds the Redis transport channel
    assert not isinstance(caught.value, VersionMismatch), str(caught.value)


def test_requirements_pin_the_messaging_stack_explicitly():
    """A transitive dependency that the broker transport relies on must be pinned, not floated."""
    from pathlib import Path

    pins = {
        line.split("==")[0].strip().lower()
        for line in (Path(__file__).resolve().parent.parent / "requirements.txt").read_text().splitlines()
        if "==" in line and not line.startswith("#")
    }
    assert {"celery", "kombu", "redis"} <= pins
