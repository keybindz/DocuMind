"""
The worker runs jobs on several threads in ONE process (so Prometheus counters
live in a single place). Lazily-initialised singletons must therefore be safe
when many threads hit them for the first time at once.
"""
import sys
import threading
import time
import types
from concurrent.futures import ThreadPoolExecutor

from app.services.embeddings import SentenceTransformerBackend
from app.services.vector_store import QdrantVectorStore

THREADS = 16


def _hammer(fn):
    barrier = threading.Barrier(THREADS)

    def run(_):
        barrier.wait()  # release all threads at the same instant
        return fn()

    with ThreadPoolExecutor(max_workers=THREADS) as pool:
        return list(pool.map(run, range(THREADS)))


def test_the_embedding_model_is_loaded_exactly_once_under_concurrency(monkeypatch):
    loads = []

    class FakeModel:
        def __init__(self, name):
            loads.append(name)
            time.sleep(0.1)  # a real model takes seconds: widen the race window

        def encode(self, texts, normalize_embeddings=True):
            return [types.SimpleNamespace(tolist=lambda: [0.0]) for _ in texts]

    monkeypatch.setitem(sys.modules, "sentence_transformers", types.SimpleNamespace(SentenceTransformer=FakeModel))
    backend = SentenceTransformerBackend()
    _hammer(lambda: backend.embed(["hello"]))
    assert len(loads) == 1  # not 16 copies of a several-hundred-MB model


def test_the_vector_store_collection_is_created_exactly_once_under_concurrency(monkeypatch):
    created, constructed = [], []

    class FakeQdrant:
        def __init__(self, url):
            constructed.append(url)
            time.sleep(0.1)

        def get_collections(self):
            return types.SimpleNamespace(collections=[])

        def create_collection(self, **kwargs):
            created.append(kwargs["collection_name"])

        def create_payload_index(self, **kwargs):
            pass

    import qdrant_client

    monkeypatch.setattr(qdrant_client, "QdrantClient", FakeQdrant)
    store = QdrantVectorStore()
    clients = _hammer(store._get_client)
    assert len(constructed) == 1 and len(created) == 1
    assert len({id(c) for c in clients}) == 1  # everyone got the same, fully-initialised client


def test_no_thread_ever_sees_a_half_initialised_qdrant_client(monkeypatch):
    """The first version published `self._client` before the collection existed."""
    seen_before_ready = []
    state = {"ready": False}

    class SlowQdrant:
        def __init__(self, url):
            pass

        def get_collections(self):
            return types.SimpleNamespace(collections=[])

        def create_collection(self, **kwargs):
            time.sleep(0.15)

        def create_payload_index(self, **kwargs):
            state["ready"] = True

    import qdrant_client

    monkeypatch.setattr(qdrant_client, "QdrantClient", SlowQdrant)
    store = QdrantVectorStore()

    def get_and_check():
        store._get_client()
        if not state["ready"]:
            seen_before_ready.append(True)

    _hammer(get_and_check)
    assert seen_before_ready == []
