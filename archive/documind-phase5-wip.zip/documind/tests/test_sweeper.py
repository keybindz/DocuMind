"""The sweeper: recovering work whose queue message was lost."""
import ast
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from app.config import get_settings
from app.models import Document, DocumentStatus, WebhookDelivery
from app.observability.metrics import sample
from app.worker import handlers

pytestmark = pytest.mark.async_queue  # lazy queue: we control exactly which jobs exist


def _signup(client, name="Alpha"):
    r = client.post(
        "/v1/auth/signup",
        json={"tenant_name": name, "email": f"o@{name.lower()}.io", "password": "supersecret123"},
    )
    return {"Authorization": f"Bearer {r.json()['token']['access_token']}"}


def _upload(client, headers, text="sweeper test content", name="a.txt"):
    r = client.post("/v1/documents", headers=headers, files={"file": (name, text.encode(), "text/plain")})
    assert r.status_code == 202, r.text
    return r.json()


def _age(db, model, seconds, **filters):
    old = datetime.now(timezone.utc) - timedelta(seconds=seconds)
    db.query(model).filter_by(**filters).update({"updated_at": old})
    db.commit()


def _sweep(session_factory, queue):
    return handlers.handle_sweep(session_factory=session_factory, queue=queue)


def _status(client, headers, doc_id):
    return client.get(f"/v1/documents/{doc_id}", headers=headers).json()["status"]


# ------------------------------------------------------------------ recovery

def test_a_document_whose_queue_message_was_lost_is_recovered(client, task_queue, session_factory, db_session):
    headers = _signup(client)
    doc = _upload(client, headers)
    task_queue.jobs.clear()  # the broker lost the message (flushed / evicted): nothing will ever process this
    _age(db_session, Document, 1000)

    assert _sweep(session_factory, task_queue).documents == 1
    task_queue.drain()
    assert _status(client, headers, doc["id"]) == "ready"


def test_a_webhook_delivery_whose_nudge_was_lost_is_recovered(client, task_queue, session_factory, db_session, webhook_sender):
    headers = _signup(client)
    client.post("/v1/webhooks", headers=headers, json={"url": "http://127.0.0.1:9/hook"})
    _upload(client, headers)
    task_queue.drain(max_jobs=1)  # ingestion ran; the delivery row is committed and its nudge queued...
    task_queue.jobs.clear()  # ...and the nudge is lost (the outbox gap)
    assert db_session.query(WebhookDelivery).one().status == "pending"
    _age(db_session, WebhookDelivery, 1000)

    assert _sweep(session_factory, task_queue).deliveries == 1
    task_queue.drain()
    assert len(webhook_sender.calls) == 1
    db_session.expire_all()
    assert db_session.query(WebhookDelivery).one().status == "succeeded"


# ---------------------------------------------------------- leaves the rest alone

def test_work_that_is_merely_recent_is_left_alone(client, task_queue, session_factory, db_session):
    headers = _signup(client)
    _upload(client, headers)
    task_queue.jobs.clear()
    _age(db_session, Document, 60)  # one minute: well inside the 15-minute threshold

    assert _sweep(session_factory, task_queue).documents == 0
    assert not task_queue.jobs


def test_finished_work_is_never_requeued_however_old(client, task_queue, session_factory, db_session, webhook_sender):
    headers = _signup(client)
    client.post("/v1/webhooks", headers=headers, json={"url": "http://127.0.0.1:9/hook"})
    _upload(client, headers, text="finishes ok")
    task_queue.drain()
    bad = client.post("/v1/documents", headers=headers, files={"file": ("x.pdf", b"nope", "application/pdf")}).json()
    task_queue.drain()
    assert _status(client, headers, bad["id"]) == "failed"
    db_session.query(Document).update({"updated_at": datetime.now(timezone.utc) - timedelta(days=30)})
    db_session.query(WebhookDelivery).update({"updated_at": datetime.now(timezone.utc) - timedelta(days=30)})
    db_session.commit()

    result = _sweep(session_factory, task_queue)
    assert (result.documents, result.deliveries) == (0, 0)  # ready, failed, succeeded: all terminal
    assert not task_queue.jobs


def test_recovered_work_is_touched_so_the_next_sweep_does_not_requeue_it_again(client, task_queue, session_factory, db_session):
    headers = _signup(client)
    _upload(client, headers)
    task_queue.jobs.clear()
    _age(db_session, Document, 1000)

    assert _sweep(session_factory, task_queue).documents == 1
    task_queue.jobs.clear()  # (the worker hasn't picked it up yet)
    assert _sweep(session_factory, task_queue).documents == 0  # a tick later it is not re-queued


# ------------------------------------------------------------ batching + scope

def test_batch_limit_is_respected_and_oldest_work_goes_first(client, task_queue, session_factory, db_session, monkeypatch):
    monkeypatch.setattr(get_settings(), "SWEEP_BATCH_LIMIT", 2)
    headers = _signup(client)
    docs = [_upload(client, headers, text=f"document {i}") for i in range(4)]
    task_queue.jobs.clear()
    for age, doc in zip((5000, 4000, 3000, 2000), docs):  # docs[0] is the oldest
        _age(db_session, Document, age, id=uuid.UUID(doc["id"]))

    assert _sweep(session_factory, task_queue).documents == 2
    assert [job[1] for job in task_queue.jobs] == [uuid.UUID(docs[0]["id"]), uuid.UUID(docs[1]["id"])]


def test_it_sweeps_every_tenant_each_with_its_own_tenant_id(client, task_queue, session_factory, db_session):
    a, b = _signup(client, "Alpha"), _signup(client, "Beta")
    doc_a, doc_b = _upload(client, a, text="alpha"), _upload(client, b, text="beta")
    task_queue.jobs.clear()
    _age(db_session, Document, 1000)

    assert _sweep(session_factory, task_queue).documents == 2
    tenant_of = {d.id: d.tenant_id for d in db_session.query(Document).all()}
    for _kind, doc_id, tenant_id, _attempt in task_queue.jobs:
        assert tenant_of[doc_id] == tenant_id  # the job carries the OWNING tenant, so the worker scopes itself correctly
    assert {j[1] for j in task_queue.jobs} == {uuid.UUID(doc_a["id"]), uuid.UUID(doc_b["id"])}


# ---------------------------------------------------------------- resilience

def test_a_broker_outage_during_a_sweep_is_survived_and_nothing_is_lost(client, task_queue, session_factory, db_session):
    headers = _signup(client)
    doc = _upload(client, headers)
    task_queue.jobs.clear()
    _age(db_session, Document, 1000)

    task_queue.fail_enqueue = True
    failures0 = sample("documind_queue_publish_failures_total")
    assert _sweep(session_factory, task_queue).documents == 0  # didn't raise; didn't claim success
    assert sample("documind_queue_publish_failures_total") - failures0 == 1
    db_session.expire_all()
    assert db_session.query(Document).one().status == DocumentStatus.pending  # untouched, still stale -> retried next tick

    task_queue.fail_enqueue = False
    assert _sweep(session_factory, task_queue).documents == 1
    task_queue.drain()
    assert _status(client, headers, doc["id"]) == "ready"


def test_sweeper_metrics_count_runs_and_requeues(client, task_queue, session_factory, db_session):
    headers = _signup(client)
    _upload(client, headers)
    task_queue.jobs.clear()
    _age(db_session, Document, 1000)
    runs0 = sample("documind_sweeper_runs_total")
    requeued0 = sample("documind_sweeper_requeued_total", {"kind": "document"})

    _sweep(session_factory, task_queue)
    assert sample("documind_sweeper_runs_total") - runs0 == 1
    assert sample("documind_sweeper_requeued_total", {"kind": "document"}) - requeued0 == 1


# ------------------------------------------------------------ scheduling + guardrails

def test_the_sweep_task_is_registered_and_scheduled_by_celery_beat():
    from app.worker import tasks  # noqa: F401 - importing registers the tasks
    from app.worker.celery_app import celery_app

    assert "documind.sweep" in celery_app.tasks
    schedule = celery_app.conf.beat_schedule["sweep-stalled-work"]
    assert schedule["task"] == "documind.sweep"
    assert schedule["schedule"] == float(get_settings().SWEEP_INTERVAL_SECONDS)


def test_the_rls_bypass_has_a_closed_list_of_users():
    """
    The system context disables tenant isolation. Its legitimate users are
    enumerated here; adding a new one must be a deliberate edit to this list,
    which shows up in code review.

    Parsed with `ast`, not grepped: a docstring that merely mentions the name
    must not trip it, and an import or attribute access must not slip past it.
    """
    bypass_names = {"set_system_context", "system_session", "get_system_db"}
    app_dir = Path(__file__).resolve().parent.parent / "app"
    users = set()
    for path in app_dir.rglob("*.py"):
        for node in ast.walk(ast.parse(path.read_text())):
            names = set()
            if isinstance(node, ast.Name):
                names.add(node.id)
            elif isinstance(node, ast.Attribute):
                names.add(node.attr)
            elif isinstance(node, (ast.ImportFrom, ast.Import)):
                names.update(alias.name.split(".")[-1] for alias in node.names)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                names.add(node.name)
            if names & bypass_names:
                users.add(str(path.relative_to(app_dir)))
    assert users == {
        "core/tenancy.py",  # defines set_system_context / system_session
        "database.py",  # defines get_system_db
        "routers/auth.py",  # signup / login: must find users before any tenant is known
        "worker/handlers.py",  # the sweeper: inherently cross-tenant
    }


def test_the_bypass_guard_itself_detects_an_aliased_import():
    """An alias must not hide a use of the bypass from the AST scan."""
    sneaky = ast.parse("from app.core.tenancy import system_session as s\nwith s(f) as db: pass\n")
    found = {a.name for n in ast.walk(sneaky) if isinstance(n, ast.ImportFrom) for a in n.names}
    assert "system_session" in found
