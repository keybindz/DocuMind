"""Logging, metrics, and health endpoints."""
import io
import json
import logging
import re
import uuid

import pytest
from prometheus_client import generate_latest

from app.config import get_settings
from app.main import app, get_readiness_checks
from app.observability import health as health_checks
from app.observability.logging import configure_logging, log_context
from app.observability.metrics import QueueDepthCollector, sample
from app.services.webhooks import SendResult
from tests.helpers import FlakyEmbedder

UUID_RE = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.I)


def _signup(client, name="Alpha"):
    r = client.post(
        "/v1/auth/signup",
        json={"tenant_name": name, "email": f"o@{name.lower()}.io", "password": "supersecret123"},
    )
    return {"Authorization": f"Bearer {r.json()['token']['access_token']}"}


def _upload(client, headers, name="a.txt", text="observability test content", mime="text/plain"):
    return client.post("/v1/documents", headers=headers, files={"file": (name, text.encode(), mime)})


@pytest.fixture()
def json_logs(client):
    """Captures what the app logs. Depends on `client` so it's installed AFTER the app's startup configured logging."""
    buf = io.StringIO()
    configure_logging("test", level="DEBUG", stream=buf)
    yield lambda: [json.loads(line) for line in buf.getvalue().splitlines() if line.strip()]
    root = logging.getLogger()
    root.handlers = [h for h in root.handlers if h.get_name() != "documind"]


# ================================================================ logging

def test_log_lines_are_json_with_request_and_tenant_context(client, json_logs):
    headers = _signup(client)
    r = client.get("/v1/tenant", headers={**headers, "X-Request-ID": "trace-me-42"})
    assert r.headers["X-Request-ID"] == "trace-me-42"

    access = [e for e in json_logs() if e["logger"] == "documind.access" and e.get("route") == "/v1/tenant"]
    assert len(access) == 1
    line = access[0]
    assert line["request_id"] == "trace-me-42"
    assert line["status"] == 200 and line["http_method"] == "GET"
    assert line["duration_ms"] >= 0
    assert line["service"] == "test"
    assert UUID_RE.fullmatch(line["tenant_id"])  # bound once the JWT was verified, with no plumbing in the route


def test_access_log_uses_the_route_template_not_the_raw_path(client, json_logs):
    headers = _signup(client)
    doc_id = str(uuid.uuid4())
    client.get(f"/v1/documents/{doc_id}", headers=headers)
    routes = [e["route"] for e in json_logs() if e["logger"] == "documind.access" and "route" in e]
    assert "/v1/documents/{document_id}" in routes
    assert not any(doc_id in r for r in routes)


def test_probe_and_scrape_traffic_is_not_logged(client, json_logs):
    client.get("/health")
    client.get("/metrics")
    assert [e for e in json_logs() if e["logger"] == "documind.access"] == []


@pytest.mark.parametrize("hostile", ["evil\nfake-log-line", "a" * 200, "has space", "semi;colon"])
def test_hostile_request_ids_are_replaced_not_logged(client, json_logs, hostile):
    """X-Request-ID is attacker-controlled. If echoed raw it could forge log lines or bloat every record."""
    try:
        r = client.get("/v1/tenant", headers={"X-Request-ID": hostile})
    except Exception:  # some clients refuse to even send a header containing a newline
        pytest.skip("client refused to send this header")
    sent = r.headers["X-Request-ID"]
    assert sent != hostile and re.fullmatch(r"[0-9a-f]{32}", sent)
    assert all(hostile not in json.dumps(e) for e in json_logs())


def test_sensitive_field_names_are_redacted():
    buf = io.StringIO()
    configure_logging("test", stream=buf)
    log = logging.getLogger("redaction-test")
    try:
        with log_context(authorization="Bearer abc123", request_id="r1"):
            log.info("hello", extra={"password": "hunter2", "webhook_secret": "whsec_x", "safe_field": "visible"})
        line = json.loads(buf.getvalue().strip().splitlines()[-1])
    finally:
        root = logging.getLogger()
        root.handlers = [h for h in root.handlers if h.get_name() != "documind"]
    assert line["authorization"] == line["password"] == line["webhook_secret"] == "[REDACTED]"
    assert line["safe_field"] == "visible" and line["request_id"] == "r1"


def test_exceptions_are_logged_with_a_traceback_in_one_json_object():
    buf = io.StringIO()
    configure_logging("test", stream=buf)
    try:
        try:
            raise ValueError("boom")
        except ValueError:
            logging.getLogger("x").exception("it failed")
        entries = [json.loads(l) for l in buf.getvalue().splitlines()]
    finally:
        root = logging.getLogger()
        root.handlers = [h for h in root.handlers if h.get_name() != "documind"]
    assert len(entries) == 1 and "ValueError: boom" in entries[0]["exception"]


def test_outbound_http_urls_never_reach_the_logs(client, json_logs, backends):
    """httpx logs full request URLs at INFO. Webhook URLs often carry secret tokens in the query string."""
    from app.services.webhooks import HttpxSender
    from tests.helpers import ReceiverServer

    server = ReceiverServer()
    try:
        backends.sender_holder.sender = HttpxSender()
        headers = _signup(client)
        client.post("/v1/webhooks", headers=headers, json={"url": server.url + "?token=SUPERSECRETTOKEN"})
        _upload(client, headers)
        assert server.requests, "the webhook was never delivered, so this test proved nothing"
    finally:
        server.close()
    assert "SUPERSECRETTOKEN" not in json.dumps(json_logs())


@pytest.mark.async_queue
def test_log_lines_emitted_inside_a_route_handler_carry_request_and_tenant(client, task_queue, json_logs):
    """
    Route handlers and dependencies run in a thread pool, which gets a COPY of the
    context. The tenant is bound in a dependency; a line logged later, from inside
    the handler, must still carry it. (This is the bug the first version had.)
    """
    headers = _signup(client)
    task_queue.fail_enqueue = True
    r = client.post(
        "/v1/documents",
        headers={**headers, "X-Request-ID": "inside-handler-1"},
        files={"file": ("a.txt", b"hello", "text/plain")},
    )
    assert r.status_code == 503
    handler_lines = [e for e in json_logs() if "Could not enqueue ingestion" in e["message"]]
    assert len(handler_lines) == 1
    assert handler_lines[0]["request_id"] == "inside-handler-1"
    assert UUID_RE.fullmatch(handler_lines[0]["tenant_id"])


def test_context_does_not_leak_between_requests(client, json_logs):
    a, b = _signup(client, "Alpha"), _signup(client, "Beta")
    client.get("/v1/tenant", headers={**a, "X-Request-ID": "req-a"})
    client.get("/v1/tenant", headers={**b, "X-Request-ID": "req-b"})
    lines = {e["request_id"]: e["tenant_id"] for e in json_logs() if e.get("route") == "/v1/tenant"}
    assert lines["req-a"] != lines["req-b"]


# ================================================================ HTTP metrics

def test_http_metrics_are_labelled_by_route_template(client):
    headers = _signup(client)
    labels = {"method": "GET", "route": "/v1/documents/{document_id}", "status": "404"}
    before = sample("documind_http_requests_total", labels)
    for _ in range(3):
        client.get(f"/v1/documents/{uuid.uuid4()}", headers=headers)  # three different ids, one series
    assert sample("documind_http_requests_total", labels) - before == 3
    assert sample("documind_http_request_duration_seconds_count", {"method": "GET", "route": "/v1/documents/{document_id}"}) >= 3


def test_unknown_paths_share_one_unmatched_series(client):
    labels = {"method": "GET", "route": "unmatched", "status": "404"}
    before = sample("documind_http_requests_total", labels)
    for i in range(5):
        client.get(f"/scanner-probe-{i}")  # a vulnerability scanner must not mint a series per path
    assert sample("documind_http_requests_total", labels) - before == 5


def test_in_progress_gauge_returns_to_baseline(client):
    before = sample("documind_http_requests_in_progress")
    client.get("/health")
    assert sample("documind_http_requests_in_progress") == before


def test_no_metric_label_ever_contains_an_identifier(client, backends):
    """Cardinality guard: exercise every major flow, then scan the whole exposition for UUID-shaped label values."""
    a, b = _signup(client, "Alpha"), _signup(client, "Beta")
    client.post("/v1/webhooks", headers=a, json={"url": "http://127.0.0.1:9/h"})
    for h in (a, b):
        doc = _upload(client, h, text=f"content for {uuid.uuid4()}").json()
        client.get(f"/v1/documents/{doc['id']}", headers=h)
        client.get(f"/v1/documents/{doc['id']}/chunks", headers=h)
        client.post("/v1/query", headers=h, json={"question": "anything"})
    client.get("/v1/documents/not-a-uuid", headers=a)
    for line in generate_latest().decode().splitlines():
        if line.startswith("documind_") and "{" in line:
            labels = line[line.index("{"): line.index("}") + 1]
            assert not UUID_RE.search(labels), f"unbounded label value in: {line}"


# ----------------------------------------------------------- /metrics access

def test_metrics_endpoint_serves_prometheus_text(client):
    r = client.get("/metrics")
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/plain")
    assert "documind_http_requests_total" in r.text and "process_cpu_seconds_total" in r.text


def test_metrics_can_be_protected_with_a_bearer_token(client, monkeypatch):
    monkeypatch.setattr(get_settings(), "METRICS_AUTH_TOKEN", "scrape-me")
    assert client.get("/metrics").status_code == 401
    assert client.get("/metrics", headers={"Authorization": "Bearer wrong"}).status_code == 401
    assert client.get("/metrics", headers={"Authorization": "Bearer scrape-me"}).status_code == 200


def test_metrics_can_be_disabled(client, monkeypatch):
    monkeypatch.setattr(get_settings(), "METRICS_ENABLED", False)
    assert client.get("/metrics").status_code == 404


# ================================================================ pipeline metrics

def _jobs(outcome):
    return sample("documind_ingestion_jobs_total", {"outcome": outcome})


def test_successful_ingestion_records_outcome_stage_timings_and_time_to_ready(client):
    headers = _signup(client)
    ready0, ttr0 = _jobs("ready"), sample("documind_document_time_to_ready_seconds_count")
    stage0 = {s: sample("documind_ingestion_stage_duration_seconds_count", {"stage": s}) for s in ("extract", "chunk", "embed")}

    _upload(client, headers)

    assert _jobs("ready") - ready0 == 1
    assert sample("documind_document_time_to_ready_seconds_count") - ttr0 == 1
    for stage, before in stage0.items():
        assert sample("documind_ingestion_stage_duration_seconds_count", {"stage": stage}) - before == 1, stage


def test_corrupt_file_counts_as_a_permanent_failure_not_a_retry(client):
    headers = _signup(client)
    perm0, retry0 = _jobs("failed_permanent"), _jobs("retry")
    _upload(client, headers, name="bad.pdf", text="not a pdf", mime="application/pdf")
    assert _jobs("failed_permanent") - perm0 == 1
    assert _jobs("retry") - retry0 == 0


def test_transient_failures_are_counted_as_retries_then_exhaustion(client, backends):
    headers = _signup(client)
    backends.embedder.backend = FlakyEmbedder(failures=99)
    retry0, exhausted0 = _jobs("retry"), _jobs("failed_exhausted")
    _upload(client, headers)
    assert _jobs("retry") - retry0 == 3  # attempts 1-3 retried
    assert _jobs("failed_exhausted") - exhausted0 == 1  # attempt 4 gave up


@pytest.mark.async_queue
def test_redelivered_finished_job_is_counted_as_skipped(client, task_queue, db_session):
    from app.models import Document

    headers = _signup(client)
    doc = _upload(client, headers).json()
    task_queue.drain()
    skipped0 = _jobs("skipped")
    task_queue.enqueue_ingestion(uuid.UUID(doc["id"]), db_session.query(Document).one().tenant_id)
    task_queue.drain()
    assert _jobs("skipped") - skipped0 == 1


# ================================================================ webhook + protection metrics

def test_webhook_outcomes_are_counted(client, webhook_sender):
    headers = _signup(client)
    client.post("/v1/webhooks", headers=headers, json={"url": "http://127.0.0.1:9/h"})
    ok0, retry0, failed0 = (sample("documind_webhook_deliveries_total", {"outcome": o}) for o in ("succeeded", "retry", "failed"))

    webhook_sender.script(SendResult(500), SendResult(200))
    _upload(client, headers, text="first")
    assert sample("documind_webhook_deliveries_total", {"outcome": "retry"}) - retry0 == 1
    assert sample("documind_webhook_deliveries_total", {"outcome": "succeeded"}) - ok0 == 1

    webhook_sender.default = SendResult(500)
    _upload(client, headers, text="second")
    assert sample("documind_webhook_deliveries_total", {"outcome": "failed"}) - failed0 == 1


def test_rate_limit_and_quota_rejections_are_counted(client):
    headers = _signup(client)
    rl0 = sample("documind_rate_limit_rejections_total", {"action": "query"})
    for _ in range(12):  # free plan burst is 10
        client.post("/v1/query", headers=headers, json={"question": "q"})
    assert sample("documind_rate_limit_rejections_total", {"action": "query"}) - rl0 == 2

    q0 = sample("documind_quota_rejections_total", {"kind": "webhooks"})
    for _ in range(3):  # free plan allows 2
        client.post("/v1/webhooks", headers=headers, json={"url": "http://127.0.0.1:9/h"})
    assert sample("documind_quota_rejections_total", {"kind": "webhooks"}) - q0 == 1


@pytest.mark.async_queue
def test_broker_outage_is_counted(client, task_queue):
    headers = _signup(client)
    before = sample("documind_queue_publish_failures_total")
    task_queue.fail_enqueue = True
    assert _upload(client, headers).status_code == 503
    assert sample("documind_queue_publish_failures_total") - before == 1


def test_queries_are_counted_and_timed(client):
    headers = _signup(client)
    q0, d0 = sample("documind_queries_total", {"synthesized": "false"}), sample("documind_query_duration_seconds_count")
    client.post("/v1/query", headers=headers, json={"question": "hello"})
    assert sample("documind_queries_total", {"synthesized": "false"}) - q0 == 1
    assert sample("documind_query_duration_seconds_count") - d0 == 1


# ================================================================ queue depth collector

def test_queue_depth_is_omitted_not_zero_when_the_broker_is_unreachable():
    """'0 jobs waiting' and 'cannot tell' must look different on a dashboard."""
    errors0 = sample("documind_queue_depth_scrape_errors_total")
    (family,) = QueueDepthCollector("redis://127.0.0.1:1/0").collect()
    assert family.samples == []
    assert sample("documind_queue_depth_scrape_errors_total") - errors0 == 1


# ================================================================ health

def _always_fails(db):
    raise ConnectionError("password authentication failed for user documind_app at db-prod-1.internal:5432")


def test_liveness_never_depends_on_dependencies(client):
    app.dependency_overrides[get_readiness_checks] = lambda: {"database": _always_fails}
    assert client.get("/health").status_code == 200  # a DB outage must not restart-loop every pod


def test_readiness_is_ok_when_dependencies_are_up(client):
    app.dependency_overrides[get_readiness_checks] = lambda: {"database": health_checks.check_database}
    r = client.get("/ready")
    assert r.status_code == 200 and r.json() == {"status": "ready", "checks": {"database": "ok"}}


def test_readiness_fails_503_naming_the_dependency_but_not_leaking_the_error(client):
    app.dependency_overrides[get_readiness_checks] = lambda: {"database": health_checks.check_database, "broker": _always_fails}
    r = client.get("/ready")
    assert r.status_code == 503
    assert r.json() == {"status": "unavailable", "checks": {"database": "ok", "broker": "unavailable"}}
    assert "documind_app" not in r.text and "db-prod-1" not in r.text  # no usernames/hostnames to a stranger


def test_default_readiness_checks_include_the_broker_only_when_celery_is_used(monkeypatch):
    monkeypatch.setattr(get_settings(), "TASK_QUEUE_BACKEND", "celery")
    assert set(health_checks.default_checks()) == {"database", "broker"}
    monkeypatch.setattr(get_settings(), "TASK_QUEUE_BACKEND", "memory")
    assert set(health_checks.default_checks()) == {"database"}
