"""S3Storage against a real S3-compatible HTTP server (moto), not mocked boto calls."""
import socket
import uuid

import pytest

from app.config import get_settings
from app.main import app
from app.models import Document
from app.services import storage as storage_module
from app.services.storage import LocalDiskStorage, S3Storage, get_storage_backend
from app.services.task_queue import get_task_queue
from tests.helpers import build_queue


@pytest.fixture(scope="module")
def s3_url():
    from moto.server import ThreadedMotoServer

    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    server = ThreadedMotoServer(ip_address="127.0.0.1", port=port, verbose=False)
    server.start()
    yield f"http://127.0.0.1:{port}"
    server.stop()


@pytest.fixture()
def bucket(s3_url):
    import boto3

    name = f"test-{uuid.uuid4().hex[:10]}"
    boto3.client(
        "s3", endpoint_url=s3_url, region_name="us-east-1", aws_access_key_id="test", aws_secret_access_key="test"
    ).create_bucket(Bucket=name)
    return name


@pytest.fixture()
def s3(s3_url, bucket):
    return S3Storage(
        bucket=bucket, endpoint_url=s3_url, access_key_id="test", secret_access_key="test", force_path_style=True
    )


def _ids():
    return uuid.uuid4(), uuid.uuid4()


def test_roundtrip_preserves_bytes_exactly(s3):
    tenant, doc = _ids()
    payload = bytes(range(256)) * 20_000  # ~5 MB of arbitrary binary
    key = s3.save(tenant_id=tenant, document_id=doc, filename="blob.bin", content=payload)
    assert s3.read(key) == payload


def test_keys_have_the_same_shape_as_local_storage_paths(s3, tmp_path):
    """So a document's `storage_path` means the same thing under either backend: switching needs no data migration."""
    tenant, doc = _ids()
    s3_key = s3.save(tenant_id=tenant, document_id=doc, filename="report.pdf", content=b"x")
    local_key = LocalDiskStorage(base_dir=str(tmp_path)).save(tenant_id=tenant, document_id=doc, filename="report.pdf", content=b"x")
    assert s3_key == local_key == f"{tenant}/{doc}_report.pdf"


def test_filenames_cannot_escape_the_tenant_prefix(s3):
    tenant, doc = _ids()
    key = s3.save(tenant_id=tenant, document_id=doc, filename="../../other-tenant/secret.txt", content=b"x")
    assert key == f"{tenant}/{doc}_secret.txt"
    assert ".." not in key


def test_reading_a_missing_object_raises_the_same_error_as_local_storage(s3):
    with pytest.raises(FileNotFoundError):
        s3.read(f"{uuid.uuid4()}/nope.txt")


def test_delete_is_idempotent(s3):
    tenant, doc = _ids()
    key = s3.save(tenant_id=tenant, document_id=doc, filename="a.txt", content=b"x")
    s3.delete(key)
    s3.delete(key)  # already gone: must not raise
    s3.delete(f"{uuid.uuid4()}/never-existed.txt")
    with pytest.raises(FileNotFoundError):
        s3.read(key)


def test_objects_are_encrypted_at_rest(s3, s3_url):
    import boto3

    tenant, doc = _ids()
    key = s3.save(tenant_id=tenant, document_id=doc, filename="a.txt", content=b"x")
    head = boto3.client(
        "s3", endpoint_url=s3_url, region_name="us-east-1", aws_access_key_id="test", aws_secret_access_key="test"
    ).head_object(Bucket=s3.bucket, Key=key)
    assert head["ServerSideEncryption"] == "AES256"


def test_tenants_are_separated_by_key_prefix(s3):
    (t1, d1), (t2, d2) = _ids(), _ids()
    k1 = s3.save(tenant_id=t1, document_id=d1, filename="a.txt", content=b"one")
    k2 = s3.save(tenant_id=t2, document_id=d2, filename="a.txt", content=b"two")
    assert k1.startswith(f"{t1}/") and k2.startswith(f"{t2}/") and k1 != k2


def test_settings_select_the_backend(monkeypatch, s3_url, bucket):
    settings = get_settings()
    monkeypatch.setattr(storage_module, "_default_backend", None)
    monkeypatch.setattr(settings, "STORAGE_BACKEND", "s3")
    monkeypatch.setattr(settings, "S3_BUCKET", bucket)
    monkeypatch.setattr(settings, "S3_ENDPOINT_URL", s3_url)
    monkeypatch.setattr(settings, "S3_ACCESS_KEY_ID", "test")
    monkeypatch.setattr(settings, "S3_SECRET_ACCESS_KEY", "test")
    monkeypatch.setattr(settings, "S3_FORCE_PATH_STYLE", True)
    chosen = get_storage_backend()
    assert isinstance(chosen, S3Storage) and chosen.bucket == bucket

    monkeypatch.setattr(storage_module, "_default_backend", None)
    monkeypatch.setattr(settings, "STORAGE_BACKEND", "floppy-disk")
    with pytest.raises(ValueError, match="Unknown STORAGE_BACKEND"):
        get_storage_backend()
    monkeypatch.setattr(storage_module, "_default_backend", None)  # don't leave a bad singleton for other tests


@pytest.fixture()
def s3_app(client, s3, backends, session_factory):
    """The API + worker both using S3 instead of the local-disk fake: the real production topology."""
    queue = build_queue(
        session_factory=session_factory,
        storage=s3,
        embedder=backends.embedder,
        vector_store=backends.vector_store,
        sender_holder=backends.sender_holder,
        eager=False,
    )
    app.dependency_overrides[get_storage_backend] = lambda: s3
    app.dependency_overrides[get_task_queue] = lambda: queue
    return queue


def _signup(client):
    r = client.post("/v1/auth/signup", json={"tenant_name": "Alpha", "email": "o@alpha.io", "password": "supersecret123"})
    return {"Authorization": f"Bearer {r.json()['token']['access_token']}"}


def test_upload_by_the_api_is_processed_by_a_worker_that_only_shares_the_bucket(client, s3_app, s3):
    headers = _signup(client)
    r = client.post("/v1/documents", headers=headers, files={"file": ("a.txt", b"stored in s3, read by the worker", "text/plain")})
    assert r.status_code == 202
    doc_id = r.json()["id"]
    s3_app.drain()  # the worker has no access to the API's filesystem -- only to S3

    body = client.get(f"/v1/documents/{doc_id}", headers=headers).json()
    assert body["status"] == "ready"
    assert "stored in s3" in client.get(f"/v1/documents/{doc_id}/content", headers=headers).json()["extracted_text"]


def test_deleting_a_document_removes_its_object(client, s3_app, s3, db_session):
    headers = _signup(client)
    doc_id = client.post("/v1/documents", headers=headers, files={"file": ("a.txt", b"delete me", "text/plain")}).json()["id"]
    key = db_session.query(Document).one().storage_path
    assert s3.read(key) == b"delete me"

    client.delete(f"/v1/documents/{doc_id}", headers=headers)
    with pytest.raises(FileNotFoundError):
        s3.read(key)


def test_a_missing_object_fails_the_job_permanently_instead_of_retrying(client, s3_app, s3, db_session):
    headers = _signup(client)
    doc_id = client.post("/v1/documents", headers=headers, files={"file": ("a.txt", b"vanishing", "text/plain")}).json()["id"]
    s3.delete(db_session.query(Document).one().storage_path)  # removed before the worker ran
    s3_app.drain()

    body = client.get(f"/v1/documents/{doc_id}", headers=headers).json()
    assert body["status"] == "failed" and "missing from storage" in body["error_message"]
    assert body["attempts"] == 1 and s3_app.retry_delays == []
