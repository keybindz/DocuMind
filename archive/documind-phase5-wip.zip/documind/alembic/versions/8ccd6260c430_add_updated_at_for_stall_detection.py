"""add updated_at for stall detection

Revision ID: 8ccd6260c430
Revises: b3aee2d92c44
Create Date: 2026-11-03 06:25:59.152714

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import app.database


# revision identifiers, used by Alembic.
revision: str = '8ccd6260c430'
down_revision: Union[str, None] = 'b3aee2d92c44'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


_TABLES = ("documents", "webhook_deliveries")


def upgrade() -> None:
    """
    Postgres can add a NOT NULL column with a now() default in one step (existing
    rows get the migration time). SQLite cannot add a column with a non-constant
    default, so there: add it nullable, backfill, then tighten via batch mode
    (which rebuilds the table, where a CURRENT_TIMESTAMP default is allowed).
    """
    timestamp = sa.DateTime(timezone=True)
    on_postgres = op.get_bind().dialect.name == "postgresql"
    for table in _TABLES:
        if on_postgres:
            op.add_column(table, sa.Column("updated_at", timestamp, server_default=sa.func.now(), nullable=False))
        else:
            op.add_column(table, sa.Column("updated_at", timestamp, nullable=True))
            op.execute(f"UPDATE {table} SET updated_at = CURRENT_TIMESTAMP")
            with op.batch_alter_table(table) as batch:
                batch.alter_column("updated_at", existing_type=timestamp, nullable=False, server_default=sa.func.now())


def downgrade() -> None:
    for table in reversed(_TABLES):
        with op.batch_alter_table(table) as batch:
            batch.drop_column("updated_at")
