"""
Database-layer isolation tests against a REAL Postgres with RLS enabled.

Skipped automatically unless both env vars are set (see README):

    RLS_TEST_ADMIN_URL  owner/superuser URL for a scratch database. The
                        schema in this DB is WIPED and rebuilt by the tests.
    RLS_TEST_APP_URL    URL of the restricted `documind_app` role for the
                        same database -- the role the real API connects as.

What these prove that the SQLite suite cannot: even code that forgets every
`WHERE tenant_id = ...` cannot read or write across tenants, because the
database itself refuses.
"""
import os
import subprocess
import sys
import uuid
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.orm import Session, sessionmaker

ADMIN_URL = os.environ.get("RLS_TEST_ADMIN_URL")
APP_URL = os.environ.get("RLS_TEST_APP_URL")

pytestmark = pytest.mark.skipif(
    not (ADMIN_URL and APP_URL), reason="set RLS_TEST_ADMIN_URL and RLS_TEST_APP_URL to run Postgres RLS tests"
)

PROJECT_ROOT = Path(__file__).resolve().parent.parent
TABLES = ["chunks", "documents", "users", "tenants"]


def _alembic(*args: str) -> None:
    env = {**os.environ, "DATABASE_URL": ADMIN_URL}
    env.pop("MIGRATION_DATABASE_URL", None)
    proc = subprocess.run(
        [sys.executable, "-m", "alembic", *args], cwd=PROJECT_ROOT, env=env, capture_output=True, text=True
    )
    assert proc.returncode == 0, f"alembic {' '.join(args)} failed:\n{proc.stdout}\n{proc.stderr}"


def _grant_app_role(admin_engine) -> None:
    app_role = create_engine(APP_URL).url.username
    with admin_engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
        conn.execute(text(f"GRANT USAGE ON SCHEMA public TO {app_role}"))
        conn.execute(text(f"GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO {app_role}"))


@pytest.fixture(scope="module")
def admin_engine():
    engine = create_engine(ADMIN_URL)
    with engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
        conn.execute(text("DROP SCHEMA public CASCADE"))
        conn.execute(text("CREATE SCHEMA public"))
    _alembic("upgrade", "head")  # also proves every migration runs on real Postgres
    _grant_app_role(engine)
    yield engine
    engine.dispose()


@pytest.fixture(scope="module")
def app_engine(admin_engine):
    engine = create_engine(APP_URL)
    yield engine
    engine.dispose()


@pytest.fixture(autouse=True)
def clean_tables(admin_engine):
    with admin_engine.begin() as conn:
        conn.execute(text(f"TRUNCATE {', '.join(TABLES)} CASCADE"))
    yield


# ---------- helpers: raw SQL under an explicit RLS context ----------

def _ctx(conn, tenant=None, bypass=False):
    conn.execute(text("SELECT set_config('app.current_tenant', :t, true)"), {"t": str(tenant) if tenant else ""})
    conn.execute(text("SELECT set_config('app.bypass_rls', :b, true)"), {"b": "on" if bypass else ""})


def rows(engine, sql, params=None, tenant=None, bypass=False):
    with engine.begin() as conn:
        _ctx(conn, tenant, bypass)
        return conn.execute(text(sql), params or {}).fetchall()


def execute(engine, sql, params=None, tenant=None, bypass=False) -> int:
    with engine.begin() as conn:
        _ctx(conn, tenant, bypass)
        return conn.execute(text(sql), params or {}).rowcount


def _insert_doc(engine, tenant, user, name, *, as_tenant=None, bypass=False):
    return execute(
        engine,
        """INSERT INTO documents (id, tenant_id, uploaded_by, filename, storage_path, mime_type,
                                  file_hash, size_bytes, status)
           VALUES (:id, :tenant, :user, :name, 'p', 'text/plain', :hash, 1, 'ready')""",
        {"id": uuid.uuid4(), "tenant": tenant, "user": user, "name": name, "hash": uuid.uuid4().hex},
        tenant=as_tenant,
        bypass=bypass,
    )


@pytest.fixture()
def seeded(app_engine):
    """Two tenants, one user + one document each, created via the system context."""
    a, b = uuid.uuid4(), uuid.uuid4()
    ua, ub = uuid.uuid4(), uuid.uuid4()
    for tid, name in ((a, "Alpha"), (b, "Beta")):
        execute(
            app_engine,
            "INSERT INTO tenants (id, name, plan, is_active) VALUES (:id, :n, 'free', true)",
            {"id": tid, "n": name},
            bypass=True,
        )
    for uid, tid, email in ((ua, a, "a@alpha.io"), (ub, b, "b@beta.io")):
        execute(
            app_engine,
            "INSERT INTO users (id, tenant_id, email, hashed_password, role) VALUES (:id, :t, :e, 'x', 'owner')",
            {"id": uid, "t": tid, "e": email},
            bypass=True,
        )
    _insert_doc(app_engine, a, ua, "alpha.txt", bypass=True)
    _insert_doc(app_engine, b, ub, "beta.txt", bypass=True)
    return {"a": a, "b": b, "ua": ua, "ub": ub}


# ---------- role sanity ----------

def test_app_role_is_not_exempt_from_rls(app_engine):
    """If the API ever connects as a superuser/BYPASSRLS role, RLS is a no-op. Guard against it."""
    (row,) = rows(app_engine, "SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user")
    assert row.rolsuper is False
    assert row.rolbypassrls is False


def test_all_tenant_tables_have_forced_rls_and_a_policy(admin_engine):
    flags = {
        r.relname: (r.relrowsecurity, r.relforcerowsecurity)
        for r in rows(admin_engine, "SELECT relname, relrowsecurity, relforcerowsecurity FROM pg_class WHERE relname = ANY(:t)", {"t": TABLES})
    }
    assert flags == {t: (True, True) for t in TABLES}
    policies = {r.tablename for r in rows(admin_engine, "SELECT tablename FROM pg_policies")}
    assert policies == set(TABLES)


# ---------- reads ----------

def test_no_tenant_context_sees_nothing(app_engine, seeded):
    for table in TABLES:
        assert rows(app_engine, f"SELECT 1 FROM {table}") == [], f"{table} leaked rows with no tenant context"


def test_tenant_sees_only_its_own_rows(app_engine, seeded):
    docs_a = rows(app_engine, "SELECT filename FROM documents", tenant=seeded["a"])
    docs_b = rows(app_engine, "SELECT filename FROM documents", tenant=seeded["b"])
    assert [r.filename for r in docs_a] == ["alpha.txt"]
    assert [r.filename for r in docs_b] == ["beta.txt"]
    assert [r.name for r in rows(app_engine, "SELECT name FROM tenants", tenant=seeded["a"])] == ["Alpha"]
    assert [r.email for r in rows(app_engine, "SELECT email FROM users", tenant=seeded["a"])] == ["a@alpha.io"]


def test_unfiltered_select_by_known_foreign_id_returns_nothing(app_engine, seeded):
    foreign = rows(app_engine, "SELECT id FROM documents", tenant=seeded["b"])[0].id
    assert rows(app_engine, "SELECT * FROM documents WHERE id = :i", {"i": foreign}, tenant=seeded["a"]) == []


def test_garbage_tenant_setting_fails_closed(app_engine, seeded):
    with pytest.raises(DBAPIError):  # not a uuid -> cast error, never "all rows"
        rows(app_engine, "SELECT 1 FROM documents", tenant="not-a-uuid")


# ---------- writes ----------

def test_cannot_insert_rows_for_another_tenant(app_engine, seeded):
    with pytest.raises(DBAPIError, match="row-level security"):
        _insert_doc(app_engine, seeded["b"], seeded["ub"], "planted.txt", as_tenant=seeded["a"])


def test_cannot_insert_with_no_context(app_engine, seeded):
    with pytest.raises(DBAPIError, match="row-level security"):
        _insert_doc(app_engine, seeded["a"], seeded["ua"], "x.txt")


def test_cannot_update_or_delete_another_tenants_rows(app_engine, seeded):
    assert execute(app_engine, "UPDATE documents SET filename = 'pwned'", tenant=seeded["a"]) == 1  # own row only
    assert execute(app_engine, "DELETE FROM documents", tenant=seeded["a"]) == 1  # own row only
    survivors = rows(app_engine, "SELECT filename FROM documents", tenant=seeded["b"])
    assert [r.filename for r in survivors] == ["beta.txt"]  # B untouched by A's blanket UPDATE/DELETE


def test_cannot_reassign_own_row_to_another_tenant(app_engine, seeded):
    with pytest.raises(DBAPIError, match="row-level security"):
        execute(app_engine, "UPDATE documents SET tenant_id = :b", {"b": seeded["b"]}, tenant=seeded["a"])


# ---------- the ORM path the app actually uses ----------

def test_orm_query_with_no_filter_is_still_scoped(app_engine, seeded):
    """The headline guarantee: an ORM query that forgot its tenant filter cannot leak."""
    from app.core.tenancy import set_tenant
    from app.models import Document

    with Session(app_engine) as session:
        set_tenant(session, seeded["a"])
        names = [d.filename for d in session.query(Document).all()]  # deliberately NO tenant filter
    assert names == ["alpha.txt"]


def test_context_is_reapplied_after_commit_and_never_leaks_on_pooled_connection(seeded):
    """
    pool_size=1 forces the same physical connection to be reused. (1) After a
    mid-request COMMIT the tenant must still apply to the next transaction.
    (2) A later session with NO tenant must not inherit the previous one's.
    """
    from app.core.tenancy import set_tenant
    from app.models import Document

    engine = create_engine(APP_URL, pool_size=1, max_overflow=0)
    try:
        with Session(engine) as s1:
            set_tenant(s1, seeded["a"])
            assert len(s1.query(Document).all()) == 1
            s1.commit()  # ends the transaction the setting was scoped to
            assert [d.filename for d in s1.query(Document).all()] == ["alpha.txt"]  # new txn, still scoped
        with Session(engine) as s2:  # same pooled connection, no tenant set
            assert s2.query(Document).all() == []
    finally:
        engine.dispose()


# ---------- migrations on real Postgres ----------

def test_rls_migration_downgrade_and_upgrade_roundtrip(admin_engine):
    _alembic("downgrade", "-1")
    assert rows(admin_engine, "SELECT 1 FROM pg_policies") == []
    _alembic("upgrade", "head")
    _grant_app_role(admin_engine)
    assert len(rows(admin_engine, "SELECT 1 FROM pg_policies")) == len(TABLES)


# ---------- the whole API on real Postgres with RLS active ----------

@pytest.fixture()
def pg_client(app_engine, tmp_path):
    from app.database import get_db
    from app.main import app
    from app.services.embeddings import DeterministicFakeBackend, get_embedding_backend
    from app.services.rate_limit import InMemoryTokenBucket, get_rate_limiter
    from app.services.storage import LocalDiskStorage, get_storage_backend
    from app.services.vector_store import InMemoryVectorStore, get_vector_store

    SessionFactory = sessionmaker(bind=app_engine, autoflush=False)

    def override_get_db():
        session = SessionFactory()
        try:
            yield session
        finally:
            session.close()

    embedder, store, limiter = DeterministicFakeBackend(), InMemoryVectorStore(), InMemoryTokenBucket()
    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_storage_backend] = lambda: LocalDiskStorage(base_dir=str(tmp_path))
    app.dependency_overrides[get_embedding_backend] = lambda: embedder
    app.dependency_overrides[get_vector_store] = lambda: store
    app.dependency_overrides[get_rate_limiter] = lambda: limiter
    with TestClient(app) as client:
        yield client
    app.dependency_overrides.clear()


def _signup(client, name):
    r = client.post(
        "/v1/auth/signup",
        json={"tenant_name": name, "email": f"o@{name.lower()}.io", "password": "supersecret123"},
    )
    assert r.status_code == 201, r.text
    return {"Authorization": f"Bearer {r.json()['token']['access_token']}"}


def _upload(client, headers, name, text_):
    return client.post("/v1/documents", headers=headers, files={"file": (name, text_.encode(), "text/plain")})


def test_full_api_flow_on_postgres_with_rls_is_isolated(pg_client):
    a = _signup(pg_client, "Alpha")  # signup/login run in the system context
    b = _signup(pg_client, "Beta")
    doc = _upload(pg_client, a, "a.txt", "alpha confidential roadmap")
    assert doc.status_code == 201 and doc.json()["status"] == "ready"
    doc_id = doc.json()["id"]

    assert pg_client.get(f"/v1/documents/{doc_id}", headers=a).status_code == 200
    assert pg_client.get(f"/v1/documents/{doc_id}", headers=b).status_code == 404
    assert pg_client.get("/v1/documents", headers=b).json()["total"] == 0
    leak = pg_client.post("/v1/query", headers=b, json={"question": "alpha confidential roadmap"})
    assert leak.json()["retrieved_chunks"] == []
    assert pg_client.post(
        "/v1/auth/login", data={"username": "o@alpha.io", "password": "supersecret123"}
    ).status_code == 200


def test_mid_request_commit_path_works_under_rls(pg_client):
    # A corrupt PDF commits mid-handler (status=failed) then refreshes the row;
    # that second transaction must still be tenant-scoped or it would 500/lose the row.
    a = _signup(pg_client, "Alpha")
    r = pg_client.post("/v1/documents", headers=a, files={"file": ("bad.pdf", b"not a pdf", "application/pdf")})
    assert r.status_code == 201 and r.json()["status"] == "failed"


def test_rls_catches_a_route_that_forgot_its_tenant_filter(pg_client, monkeypatch):
    """
    Simulate the exact bug RLS exists for: a developer ships a lookup with no
    tenant filter. Application-layer isolation is now gone -- the database
    must still refuse.
    """
    from fastapi import HTTPException

    from app.models import Document
    from app.routers import documents as documents_router

    def buggy_lookup(db, document_id, tenant_id):  # NOTE: ignores tenant_id entirely
        doc = db.get(Document, document_id)
        if doc is None:
            raise HTTPException(status_code=404, detail="Document not found")
        return doc

    a = _signup(pg_client, "Alpha")
    b = _signup(pg_client, "Beta")
    doc_id = _upload(pg_client, a, "a.txt", "alpha only").json()["id"]

    monkeypatch.setattr(documents_router, "_get_owned_document", buggy_lookup)
    assert pg_client.get(f"/v1/documents/{doc_id}", headers=a).status_code == 200  # owner still works
    assert pg_client.get(f"/v1/documents/{doc_id}", headers=b).status_code == 404  # RLS saved us
