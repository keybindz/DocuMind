import hashlib
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, status
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import get_db
from app.core.plans import limits_for
from app.dependencies import get_current_user, rate_limit
from app.models import Chunk, Document, DocumentStatus, Tenant, User
from app.schemas import ChunkListOut, ChunkOut, DocumentContentOut, DocumentListOut, DocumentOut
from app.services.embeddings import EmbeddingBackend, get_embedding_backend
from app.services.extraction import ExtractionError, extract_text
from app.services.indexing import index_document
from app.services.storage import StorageBackend, get_storage_backend
from app.services.vector_store import VectorStore, get_vector_store

router = APIRouter(prefix="/v1/documents", tags=["documents"])
settings = get_settings()


def _get_owned_document(db: Session, document_id: uuid.UUID, tenant_id: uuid.UUID) -> Document:
    """
    Fetches a document scoped to the caller's tenant. Filtering by tenant_id
    in the WHERE clause (rather than fetching by id then checking) means a
    request for another tenant's document ID returns an indistinguishable
    404 — not a 403 that would confirm the ID exists.
    """
    document = (
        db.query(Document)
        .filter(Document.id == document_id, Document.tenant_id == tenant_id)
        .first()
    )
    if document is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    return document


@router.post(
    "",
    response_model=DocumentOut,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(rate_limit("upload"))],
)
async def upload_document(
    file: UploadFile,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    storage: StorageBackend = Depends(get_storage_backend),
    embedding_backend: EmbeddingBackend = Depends(get_embedding_backend),
    vector_store: VectorStore = Depends(get_vector_store),
):
    """
    Uploads a document, extracts its text, then chunks + embeds it into the
    vector store — all synchronously.

    Synchronous extraction is a deliberate Phase 1 simplification for small
    files/fast feedback in a demo. Phase 4 moves this to `pending` + a queued
    background job so upload latency doesn't scale with file size.
    """
    if file.content_type not in settings.ALLOWED_MIME_TYPES:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=f"Unsupported file type: {file.content_type}",
        )

    content = await file.read()
    if len(content) > settings.MAX_UPLOAD_SIZE_BYTES:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File exceeds max size of {settings.MAX_UPLOAD_SIZE_BYTES} bytes",
        )
    if not content:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Uploaded file is empty")

    file_hash = hashlib.sha256(content).hexdigest()

    # Dedupe: if this tenant already uploaded this exact file, return it as-is
    # rather than reprocessing and storing a duplicate copy.
    existing = (
        db.query(Document)
        .filter(Document.tenant_id == current_user.tenant_id, Document.file_hash == file_hash)
        .first()
    )
    if existing:
        return existing  # dedupe hits are free: no new storage, so no quota use

    # Plan quota. Checked after dedupe so re-uploading a file you already
    # have never counts against (or is blocked by) the limit.
    tenant = db.get(Tenant, current_user.tenant_id)
    plan = tenant.plan if tenant else "free"
    max_docs = limits_for(plan).max_documents
    current_count = db.query(Document).filter(Document.tenant_id == current_user.tenant_id).count()
    if current_count >= max_docs:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Document quota exceeded for plan '{plan}' ({max_docs} documents). Delete documents or upgrade.",
        )

    document = Document(
        tenant_id=current_user.tenant_id,
        uploaded_by=current_user.id,
        filename=file.filename or "untitled",
        storage_path="",  # set below once we know the document id
        mime_type=file.content_type,
        file_hash=file_hash,
        size_bytes=len(content),
        status=DocumentStatus.pending,
    )
    db.add(document)
    db.flush()  # populate document.id

    storage_path = storage.save(
        tenant_id=current_user.tenant_id,
        document_id=document.id,
        filename=document.filename,
        content=content,
    )
    document.storage_path = storage_path
    document.status = DocumentStatus.extracting

    try:
        text = extract_text(content, file.content_type)
        document.extracted_text = text
        document.char_count = len(text)
    except ExtractionError as exc:
        document.status = DocumentStatus.failed
        document.error_message = str(exc)
        db.commit()
        db.refresh(document)
        return document

    index_document(db, document, embedding_backend=embedding_backend, vector_store=vector_store)

    db.commit()
    db.refresh(document)
    return document


@router.get("", response_model=DocumentListOut)
def list_documents(
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    base_query = db.query(Document).filter(Document.tenant_id == current_user.tenant_id)
    total = base_query.count()
    items = (
        base_query.order_by(Document.created_at.desc()).offset(offset).limit(limit).all()
    )
    return DocumentListOut(items=items, total=total, limit=limit, offset=offset)


@router.get("/{document_id}", response_model=DocumentOut)
def get_document(
    document_id: uuid.UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _get_owned_document(db, document_id, current_user.tenant_id)


@router.get("/{document_id}/content", response_model=DocumentContentOut)
def get_document_content(
    document_id: uuid.UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    document = _get_owned_document(db, document_id, current_user.tenant_id)
    if document.status != DocumentStatus.ready:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Document is not ready (status={document.status.value})",
        )
    return DocumentContentOut(id=document.id, filename=document.filename, extracted_text=document.extracted_text)


@router.get("/{document_id}/chunks", response_model=ChunkListOut)
def list_chunks(
    document_id: uuid.UUID,
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Debug/inspection endpoint: see exactly what chunks a document was split into."""
    _get_owned_document(db, document_id, current_user.tenant_id)  # 404s if not owned
    base_query = db.query(Chunk).filter(
        Chunk.document_id == document_id, Chunk.tenant_id == current_user.tenant_id
    )
    total = base_query.count()
    items = base_query.order_by(Chunk.chunk_index).offset(offset).limit(limit).all()
    return ChunkListOut(items=items, total=total, limit=limit, offset=offset)


@router.delete("/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_document(
    document_id: uuid.UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    storage: StorageBackend = Depends(get_storage_backend),
    vector_store: VectorStore = Depends(get_vector_store),
):
    document = _get_owned_document(db, document_id, current_user.tenant_id)
    storage.delete(document.storage_path)
    vector_store.delete_by_document(tenant_id=current_user.tenant_id, document_id=document.id)
    db.delete(document)  # cascades to Chunk rows via relationship(cascade="all, delete-orphan")
    db.commit()
    return None
