# DocuMind — Phases 1–3

Multi-tenant document intelligence platform.

- **Phase 1:** tenant/user auth (JWT), document upload, synchronous text
  extraction (PDF, DOCX, TXT, MD).
- **Phase 2 (this update):** chunking, embeddings, a vector store, and a
  RAG query endpoint (`POST /v1/query`) with optional LLM answer synthesis.

- **Phase 3 (this update):** database-enforced tenant isolation (Postgres
  Row-Level Security), per-plan document quotas, and per-tenant Redis
  token-bucket rate limiting.

Still no background workers / queue (Phase 4) — see "What's deliberately
not here yet" below.

> **Upgrading from Phase 2?** The Postgres container now creates a
> restricted `documind_app` role on *first* start only, so run
> `docker compose down -v` once to recreate the volume (this wipes dev data).

## Stack

- **FastAPI** — API layer
- **PostgreSQL** (via SQLAlchemy 2.0) — relational data: tenants, users, documents, chunks
- **Redis** — per-tenant rate limiting (atomic Lua token bucket)
- **Qdrant** — vector store, for semantic search over chunk embeddings
- **sentence-transformers** (`all-MiniLM-L6-v2`) — local embedding model, no API key required
- **Anthropic API** (optional) — LLM answer synthesis over retrieved chunks
- **Alembic** — schema migrations
- **JWT** (python-jose) + **bcrypt** (passlib) — auth
- **pypdf / python-docx** — text extraction
- **Docker Compose** — local dev environment
- **pytest** — test suite (runs against in-memory SQLite + in-memory vector store, no Docker required)

## Architecture notes worth knowing before you read the code

- **Multi-tenancy is in the schema from day one.** Every tenant-owned table
  (`users`, `documents`) has a `tenant_id`, and every query is filtered by
  the caller's tenant. Row-Level Security as a second enforcement layer,
  plus explicit cross-tenant-leak tests, are added in Phase 3 — the schema
  won't need to change then.
- **Cross-dialect UUID type** (`app/database.py::GUID`): native `UUID` on
  Postgres, `CHAR(36)` on SQLite. This is what lets the test suite run fast
  against in-memory SQLite while production runs Postgres, from the exact
  same models.
- **Storage is behind an interface** (`app/services/storage.py`). Phase 1
  uses local disk; a later phase swaps in an S3/MinIO-backed implementation
  without touching the API or the schema — `storage_path` is already shaped
  like an S3 key (`{tenant_id}/{document_id}_{filename}`).
- **Extraction is synchronous for now** (`app/services/extraction.py`).
  Phase 4 moves this behind a message queue + worker; the extraction
  function itself won't change, only who calls it and when.
- **404, not 403, for cross-tenant access.** Looking up another tenant's
  document by ID returns 404 rather than 403 — it doesn't confirm the ID
  exists. See `test_tenant_isolation_cannot_see_other_tenants_documents`.
- **Embeddings and the vector store are behind swappable interfaces**, same
  pattern as storage (`app/services/embeddings.py`,
  `app/services/vector_store.py`). Production uses `sentence-transformers` +
  Qdrant; tests inject a deterministic hash-based fake embedder and an
  in-memory vector store, so the full chunk → embed → search pipeline is
  unit-testable without a GPU, a model download, or a running Qdrant
  instance. The fake backend has **no semantic understanding** — it only
  guarantees identical text → identical vector — so tests that need to
  prove *ranking* correctness query with exact chunk text rather than
  paraphrases (see the docstring on `test_query_retrieves_relevant_chunk`).
- **Vector store payloads never carry chunk text**, only `tenant_id` /
  `document_id` (`chunk_id` is the point id itself). Chunk content is the
  source of truth in Postgres and is fetched by id after a vector search
  returns matches. This keeps the vector store from becoming a second
  source of truth for content.
- **Tenant isolation extends to vector search**, not just SQL. Every
  `vector_store.search()` call requires a `tenant_id` and applies it as a
  hard filter — there's no code path that can run an unfiltered or
  cross-tenant vector search. See `test_vector_store_tenant_isolation` and
  `test_query_tenant_isolation`.
- **LLM synthesis degrades gracefully.** `POST /v1/query` always performs
  real retrieval; if `ANTHROPIC_API_KEY` isn't set it returns the retrieved
  chunks with `answer_synthesized: false` instead of failing the request.
  This is also what keeps the test suite free of any dependency on a live
  API key.

## Phase 3: how tenant isolation works now

Isolation is enforced in three independent layers, so a bug in one doesn't
become a breach:

1. **Application filters** — every query still has `WHERE tenant_id = ...`
   (unchanged from Phase 1), and cross-tenant lookups return 404, not 403.
2. **Postgres Row-Level Security** (`alembic/versions/a3c1f9e27b10_*`) —
   `ENABLE` + `FORCE` RLS with a policy on `tenants`, `users`, `documents`,
   `chunks`. `USING` hides other tenants' rows; `WITH CHECK` stops a tenant
   writing rows into someone else's tenant (or re-assigning its own rows).
   If application code forgets layer 1, the database refuses anyway —
   `test_rls_catches_a_route_that_forgot_its_tenant_filter` demonstrates it.
3. **Vector search filters** — `tenant_id` is mandatory on every
   `vector_store.search()` (Phase 2), now backed by a Qdrant payload index.

How the tenant reaches Postgres (`app/core/tenancy.py`): the verified JWT's
`tenant_id` is stored on the SQLAlchemy session, and an `after_begin` hook
runs `set_config('app.current_tenant', ..., true)` at the start of **every**
transaction. It must be per-transaction because the setting is
transaction-scoped and handlers commit mid-request; a pooled connection
therefore can never carry one request's tenant into another's
(`test_context_is_reapplied_after_commit_and_never_leaks_on_pooled_connection`).
No tenant set → empty setting → every policy matches nothing (fails closed).

Things worth knowing (and being ready to explain):

- **The API must not connect as a superuser.** Postgres exempts superusers
  and `BYPASSRLS` roles from RLS unconditionally, which would silently turn
  every policy into a no-op. The API connects as `documind_app`
  (`scripts/init-db.sql`: no superuser, no BYPASSRLS, no DDL); only Alembic
  uses the owner role (`MIGRATION_DATABASE_URL`). A test asserts the app
  role has neither flag.
- **The one escape hatch** is the *system context* (`app.bypass_rls`), used
  only by signup/login, which must find users before a tenant is known.
  Trade-off: it's a session setting, so anything able to run arbitrary SQL
  could set it (the alternative is `SECURITY DEFINER` functions for
  signup/login — stricter, more ceremony). Mitigation here:
  `test_system_context_only_on_auth_routes` fails the build if any route
  outside `/v1/auth/` can obtain it.
- **Plans** (`app/core/plans.py`):

  | Plan | Max documents | Query rate (burst / per min) | Upload rate (burst / per min) |
  |---|---|---|---|
  | free | 25 | 10 / 10 | 5 / 5 |
  | pro | 1,000 | 60 / 60 | 30 / 30 |
  | enterprise | 50,000 | 300 / 300 | 120 / 120 |

  Quota breach → `403`. Rate limit breach → `429` + `Retry-After`. Both are
  per **tenant**, not per user, so adding users doesn't multiply a budget and
  one noisy tenant can't consume another's. Re-uploading an existing file
  (dedupe hit) costs no quota. Billing/plan changes arrive in Phase 6; for
  now change a plan with
  `UPDATE tenants SET plan = 'pro' WHERE name = '...'` (as the owner role).
- **Rate limiter fails open** if Redis is unreachable (logged). It's a
  protection layer, not a correctness layer; quotas live in Postgres and are
  unaffected. The Redis check-and-decrement is one Lua script (atomic across
  API replicas, uses Redis's clock); a 80-way concurrent test proves it
  admits exactly `capacity` requests.

## Quickstart (Docker — recommended)

```bash
docker compose up --build
```

This starts Postgres, Redis, Qdrant, and the API (which runs
`alembic upgrade head` as the owner role, then serves as the restricted
role) with hot-reload. The API is at
`http://localhost:8000`, interactive docs at `http://localhost:8000/docs`,
Qdrant's own dashboard at `http://localhost:6333/dashboard`.

The embedding model (~80MB) downloads on the API container's first startup
and is cached in a named volume afterwards, so subsequent restarts are
fast. To enable LLM answer synthesis on `/v1/query`, export a key before
starting:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
docker compose up --build
```

Without it, `/v1/query` still performs real retrieval — it just returns
`answer_synthesized: false` and `answer: null` instead of a generated
answer.

Schema now comes exclusively from Alembic (`AUTO_CREATE_TABLES=false`) —
`create_all()` can't create RLS policies. Phase 5 moves the migrate step
into CI/CD as an explicit deploy job.

## Quickstart (without Docker)

Requires Python 3.12+ and a running Postgres instance (or just use the
SQLite default for a quick look).

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env      # edit DATABASE_URL if not using the SQLite default
uvicorn app.main:app --reload
```

## Demo script (run against either setup)

```bash
BASE=http://localhost:8000

# 1. Sign up — creates a tenant + owner user, returns a JWT
curl -s -X POST $BASE/v1/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"tenant_name":"Acme Corp","email":"demo@acme.io","password":"supersecret123"}' | tee /tmp/signup.json
TOKEN=$(python -c "import json;print(json.load(open('/tmp/signup.json'))['token']['access_token'])")

# 2. Log in (alternative to using the signup token directly)
curl -s -X POST $BASE/v1/auth/login \
  -d "username=demo@acme.io&password=supersecret123"

# 3. Upload a document
echo "Vector databases enable semantic search over unstructured text." > sample.txt
curl -s -X POST $BASE/v1/documents \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@sample.txt;type=text/plain" | tee /tmp/upload.json
DOC_ID=$(python -c "import json;print(json.load(open('/tmp/upload.json'))['id'])")

# 4. List documents
curl -s $BASE/v1/documents -H "Authorization: Bearer $TOKEN"

# 5. Get extracted content
curl -s $BASE/v1/documents/$DOC_ID/content -H "Authorization: Bearer $TOKEN"

# 6. Confirm auth is enforced
curl -s -o /dev/null -w "%{http_code}\n" $BASE/v1/documents   # -> 401

# 7. Inspect the chunks it was split into
curl -s $BASE/v1/documents/$DOC_ID/chunks -H "Authorization: Bearer $TOKEN"

# 8. Ask a question over your documents (RAG)
curl -s -X POST $BASE/v1/query \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"question": "What do my documents say about semantic search?", "top_k": 5}'
# -> real retrieved chunks always; "answer" is non-null only if
#    ANTHROPIC_API_KEY was set when the container started

# 9. See your plan, usage and limits
curl -s $BASE/v1/tenant -H "Authorization: Bearer $TOKEN"

# 10. Trip the rate limiter (free plan: burst of 10 queries) -> 429 + Retry-After
for i in $(seq 1 12); do
  curl -s -o /dev/null -w "%{http_code} " -X POST $BASE/v1/query \
    -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
    -d '{"question":"hello"}'
done; echo

# 11. Prove isolation: sign up a SECOND tenant and try to read the first one's doc
TOKEN_B=$(curl -s -X POST $BASE/v1/auth/signup -H "Content-Type: application/json" \
  -d '{"tenant_name":"Other Co","email":"b@other.io","password":"supersecret123"}' \
  | python -c "import sys,json;print(json.load(sys.stdin)['token']['access_token'])")
curl -s -o /dev/null -w "%{http_code}\n" $BASE/v1/documents/$DOC_ID -H "Authorization: Bearer $TOKEN_B"   # -> 404

# 12. Delete it
curl -s -o /dev/null -w "%{http_code}\n" -X DELETE $BASE/v1/documents/$DOC_ID \
  -H "Authorization: Bearer $TOKEN"   # -> 204
```

Or skip curl entirely and use the Swagger UI at `/docs` — click "Authorize",
paste `Bearer <token>` from the signup response, and try every endpoint
interactively.

## Running the tests

```bash
pytest -v          # 65 tests, ~18s, needs NOTHING running
```

Without any services, the Postgres/Redis integration tests (20) skip
cleanly. The 65 that run use in-memory SQLite, a deterministic fake
embedder, an in-memory vector store, and an in-memory token bucket (see
`tests/conftest.py`):

- **Phase 1:** auth validation, JWT enforcement, upload + extraction,
  corrupt/unsupported files, dedupe, pagination, deletion
- **Phase 2:** chunking, fake-embedder determinism, vector store
  ranking/filtering/deletion, upload → chunk → embed → `/v1/query` end to end
- **Phase 3 (app layer):** a cross-tenant attack matrix over every
  document route, `document_ids` poisoning on `/v1/query`, tenant-scoped
  dedupe, forged/legacy/unknown-user tokens, the "no bypass outside auth"
  guard, token-bucket math with a fake clock, 429 + `Retry-After`, per-tenant
  budgets, plan tiers, quota edge cases (dedupe, delete frees quota)

**Integration tests (real Postgres + real Redis)** — this is where RLS and
the Lua limiter are actually proven:

```bash
docker compose up -d postgres redis      # init-db.sql creates the roles + a scratch DB
export RLS_TEST_ADMIN_URL=postgresql+psycopg2://documind:documind@localhost:5432/documind_test
export RLS_TEST_APP_URL=postgresql+psycopg2://documind_app:documind_app@localhost:5432/documind_test
export REDIS_TEST_URL=redis://localhost:6379/15
pytest -v                                # 85 tests
```

The RLS suite wipes and rebuilds `documind_test` (never your dev DB). It
runs every migration on real Postgres, then, as the restricted role: reads
with no/garbage/other-tenant context, cross-tenant INSERT/UPDATE/DELETE, tenant
re-assignment, an unfiltered ORM query, context reuse across a pooled
connection, a migration downgrade/upgrade round-trip, and the full API with
RLS live.

**Sanity check of the tests themselves:** with the RLS migration's
`upgrade()` stubbed out, 13 of the 16 RLS tests fail (the 3 survivors are the
role-flag check and two API-flow tests that app-layer filters satisfy on
their own). The tests depend on the policies, not on app code getting lucky.

## Migrations

An initial migration already exists (`alembic/versions/`). To use Alembic
instead of `AUTO_CREATE_TABLES`:

```bash
export AUTO_CREATE_TABLES=false
alembic upgrade head        # apply
alembic downgrade base      # roll back (tested — both directions work)
alembic revision --autogenerate -m "description"   # after changing models.py
```

## API surface (Phase 1)

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/v1/auth/signup` | — | Create tenant + owner user, returns JWT |
| POST | `/v1/auth/login` | — | Exchange email/password for JWT |
| POST | `/v1/documents` | JWT | Upload, extract, chunk, embed (rate limited; 403 over quota) |
| GET | `/v1/documents` | JWT | List tenant's documents (paginated) |
| GET | `/v1/documents/{id}` | JWT | Get one document's metadata |
| GET | `/v1/documents/{id}/content` | JWT | Get extracted text (409 if not ready) |
| GET | `/v1/documents/{id}/chunks` | JWT | Inspect how a document was chunked |
| DELETE | `/v1/documents/{id}` | JWT | Delete document + chunks + vectors + underlying file |
| POST | `/v1/query` | JWT | RAG query: retrieve relevant chunks, optionally synthesize an answer (rate limited) |
| GET | `/v1/tenant` | JWT | Your tenant's plan, document usage, and limits |
| GET | `/health` | — | Liveness check |

## What's deliberately *not* here yet

- Async ingestion via message queue + worker, webhooks → **Phase 4**
- Observability (metrics/tracing/logging), CI/CD, Kubernetes → **Phase 5**
- Hybrid search (keyword + vector), re-ranking, usage-based billing → **Phase 6**
